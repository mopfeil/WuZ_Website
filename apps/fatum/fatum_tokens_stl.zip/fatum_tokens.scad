// FATUM – Spielmarken (Münzen) für das Orakel-Gewölbe, 16.11.2026
// 4 Helden (Schwert, Stern, Pfeil, Schild), Siegel (Schlüssel, 3x drucken), Wächter (Auge)
// Münze D x T, Symbol + Zierring INLAY tief bündig eingelegt (zweite Farbe).
// part: "body" | "symbol" | "sym2d" (nur Symbol, für SVG) | "all" (Vorschau)
part = "all";
id   = 1;      // 1 Schwert, 2 Stern, 3 Pfeil, 4 Schild, 5 Schlüssel/Siegel, 6 Auge/Wächter
D = 25; T = 3.0; INLAY = 0.6;
RING_O = 11.2; RING_I = 10.2;   // Zierring
$fn = 96;

module sym(id) {
  if (id == 1) {                       // Schwert
    polygon([[-1.1,-3],[1.1,-3],[1.1,6],[0,8.2],[-1.1,6]]);
    translate([-4,-4.6]) square([8,1.8]);
    translate([-0.9,-7.6]) square([1.8,3.2]);
    translate([0,-7.6]) circle(r=1.5, $fn=32);
  } else if (id == 2) {                // Stern
    polygon([for (i=[0:9]) let(r = i%2==0 ? 8.4 : 3.6, a = 90+i*36) [r*cos(a), r*sin(a)]]);
  } else if (id == 3) {                // Pfeil
    translate([-0.8,-7]) square([1.6,11.5]);
    polygon([[-3.3,4],[3.3,4],[0,8.6]]);
    for (s=[-1,1]) scale([s,1]) polygon([[0.8,-7],[3.6,-8.6],[3.6,-5.4],[0.8,-3.8]]);
  } else if (id == 4) {                // Schild mit Kreuz
    difference() {
      polygon([[-6,7],[6,7],[6,0.5],[4.6,-3.5],[2.5,-6.2],[0,-8],[-2.5,-6.2],[-4.6,-3.5],[-6,0.5]]);
      translate([-0.8,-5.2]) square([1.6,10.6]);
      translate([-4.4,1.6]) square([8.8,1.6]);
    }
  } else if (id == 5) {                // Schlüssel (Siegel)
    translate([0,4.6]) difference() { circle(r=3.7, $fn=48); circle(r=1.8, $fn=32); }
    translate([-0.9,-8]) square([1.8,9.6]);
    translate([0.9,-8]) square([2.6,1.7]);
    translate([0.9,-5.0]) square([2.0,1.7]);
  } else {                             // Auge (Wächter)
    difference() { lens(); offset(delta=-1.4) lens(); }
    circle(r=2.0, $fn=40);
  }
}
module lens() intersection_for (s=[-1,1]) translate([0,s*4.5]) circle(r=9.5, $fn=120);

module outline() difference() {
  circle(d=D, $fn=144);
  for (i=[0:35]) rotate(i*10) translate([D/2+0.15,0]) circle(r=0.55, $fn=16);  // Riffelrand
}
module deco(id) { sym(id); difference() { circle(r=RING_O); circle(r=RING_I); } }
module body(id) difference() {
  linear_extrude(T) outline();
  translate([0,0,T-INLAY]) linear_extrude(INLAY+0.01) deco(id);
}
module symbol(id) translate([0,0,T-INLAY]) linear_extrude(INLAY) deco(id);

if (part == "body") body(id);
else if (part == "symbol") symbol(id);
else if (part == "sym2d") sym(id);
else for (i=[1:6]) translate([((i-1)%3)*30, -floor((i-1)/3)*30]) {
  color("#3b3350") body(i); color("#e8c468") symbol(i);
}
