# WuZ-Ergänzungsbox (27.10.2026)

**v3 (27.10.2026):** Die Dose ist nicht mehr rund. Der Grundriss ist ein **Rechteck, so breit wie Brett-Hülle plus Wände (89 mm), an beiden Enden durch Kreissegmente abgeschlossen**. Das Bajonett sitzt nur auf diesen beiden Segmenten (ein Nocken pro Ende). Die Streichholzfächer liegen jetzt in den Endsegmenten. Statt Fingermulden gibt es ein Drückloch im Boden. Die NIM-Platte folgt dem Grundriss. Runde v2 in `v2_rund/`, v1 (30,3 hoch) in `v1_30mm/`.

**Schriftzug im Deckel (31.10.2026):** „Wissenschaft / und / Zauberkunst“ (Roboto Condensed Bold 13 / 8,5 / 13 mm, Zeilen y ±17,5) und eine Rahmenlinie 0,8 mm, die 5 mm innerhalb der Außenkante dem Umriss folgt. Einlage 0,6 tief in zweiter Farbe in der Deckeloberseite (liegt beim Druck auf dem Bett), wie bei der Grundausstattung. Liest sich bei geschlossenem Deckel von oben. Ausschalten mit `TXT_ON = false`.

**QR-Code im Boden:** `HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/X` (Version 2-M, Modul 1,2 → 30 mm), als Einlage 0,6 tief in zweiter Farbe, rechts neben dem Drückloch, gespiegelt (liest sich von unten). Im Render dekodiert. Die Seite `/X/` (DE/EN) ist seit 28.10.2026 online: Einleitung, Karten B, I, N und Hinweise zur kleinen NIM-KI.

**Außenmaß 138,8 × 89 × 35,3 mm** (Unterteil 26,6 + Deckel). Quelle: `ergaenzungsbox.scad`.

## Inhalt
| Wo | Was |
|---|---|
| **Boden, Schacht in der Mitte** | Brett der Wunder v4.1 in der Hülle (88,8 × 85 × 8,8), Gummiband bleibt drauf |
| **Einsatz** (auf dem Brett, 15,5 hoch, Boden 6) | Inverter V9 (Ø 48,5 × 9,1), Kugelbox mit Deckel (Ø 17), QR-Platte des Bretts mit eingedrückter Münze, ein freies Fach (Gummibänder o. Ä.) |
| **Kreissegmente an beiden Enden** | je ein **Streichholzfach** (18,2 tief, 85,8 breit), die Hölzer liegen quer. Zusammen ca. 97 Hölzer à 50 mm (Schätzung, Packungsdichte 0,65): 82 für das Brett + 15 zum Spielen |
| **Boden** | Drückloch Ø 25 unter dem Brett: von unten durchdrücken, dann heben sich Hülle und Einsatz zusammen heraus |
| **Deckel** | kleine **NIM-KI** als Einlegeplatte (132,5 × 85,3 × 6, gleicher Grundriss) |

Der Radius der Endsegmente (innen 64,2) ist so berechnet, dass `N_NEED` = 97 Hölzer hineinpassen. Bei anderer Holzzahl oder -größe passt sich die Länge der Dose an.

## NIM-KI im Deckel
Gleiches Spiel wie das große Steckbrett (`ki_lernbretter/nim_brett.scad`): 15 Hölzchen, 1, 2 oder 3 nehmen, wer das letzte nimmt, verliert. 14 Felder (15 … 2) in Reihen 3-4-4-3 (Feld 27 × 19), je Feld bis zu drei Zeilen „1/2/3“ mit vier Löchern Ø 3,2. **Statt gedruckter Stifte steckt man Streichhölzer hinein**, Kopf nach oben. Start: zwei Hölzer pro Zeile (82 Stück). Der Regeltext läuft auf den beiden Endbögen. Zum Spielen den Deckel abnehmen und umgedreht hinlegen. Vor dem Schließen kommen die Hölzer zurück in die Fächer.

Die Platte ist ein eigenes Teil. Sie liegt innen auf der Deckelplatte, vier Quetschrippen an den Längsseiten halten sie, über die Kerbe in der Mitte einer Längsseite lässt sie sich herausheben. Die Deckelplatte schließt die Löcher nach unten ab (6 mm Stecktiefe). Die Schrift ist 0,6 erhaben in zweiter Farbe.

## Bajonett
Zwei Nocken (12 mm Bogen, 1,2 radial, 45°-Flanken) sitzen außen am Kragen des Unterteils, einer auf jedem Endsegment, auf einem gemeinsamen Teilkreis. Innen im Deckelrand liegen die passenden L-Nuten. Der Deckelrand reicht nur an den Enden über den Kragen. An den Längsseiten beginnt die Deckelwand erst über der Oberkante des Unterteils (0,4 mm Fuge), deshalb lässt sich der Deckel trotz der flachen Seiten drehen.
- Deckel um 30° verdreht aufsetzen (Kerben am Deckelrand über den Kerben an der Schulter), herunterdrücken.
- **30° im Uhrzeigersinn** drehen, bis die Seiten bündig stehen. Die Nut steigt dabei um 0,4 mm und zieht den Deckel herunter.
- Eine Rastnase (0,2 mm Übermaß) 5° vor dem Ende lässt den Nocken spürbar einrasten.

Kollisionsprüfung im Modell (ganzes Unterteil gegen ganzen Deckel, Drehweg 0 bis 30°): Kontakt nur an der Rastnase. Die Festigkeit der Rastung ist ungetestet. Ist sie zu stramm, `DET_H` verkleinern (0,5 → 0,1 mm Übermaß). Hält sie zu wenig, `DET_H` auf 0,7 setzen. Mit nur zwei Nocken trägt jeder mehr. Wackelt der Deckel, kann `G_CLR_A` auf 0,2 sinken.

## Dateien
| Datei | Druck |
|---|---|
| `ergaenzungsbox_unterteil.stl` + `ergaenzungsbox_qr.stl` | EIN Objekt mit zwei Teilen (QR = Farbe 2), Boden aufs Bett, ohne Stützen. Für Bambu „Teil hinzufügen“: `ergaenzungsbox_qr_teil.stl` |
| `ergaenzungsbox_deckel.stl` + `ergaenzungsbox_schrift.stl` | EIN Objekt mit zwei Teilen (Schrift = Farbe 2), Deckelplatte aufs Bett (Rand nach oben). Für Bambu „Teil hinzufügen“: `ergaenzungsbox_schrift_teil.stl`. Fertig: `3mf/ergaenzungsbox_2_deckel_schrift.3mf` |
| `ergaenzungsbox_nim.stl` + `ergaenzungsbox_nim_text.stl` | EIN Objekt mit zwei Teilen (Schrift = Farbe 2). Für Bambu „Teil hinzufügen“: `ergaenzungsbox_nim_text_teil.stl` |
| `ergaenzungsbox_einsatz.stl` | Boden aufs Bett |
| `3mf/ergaenzungsbox_1_unterteil.3mf`, `…_2_deckel.3mf`, `…_3_nim_einsatz.3mf` | drei Druckplatten; `…_2_deckel.3mf` ist noch der Deckel ohne Schrift (27.10.) |

Bilder: `ergaenzungsbox_zu.png`, `ergaenzungsbox_deckel_schrift.png` (Draufsicht Deckel), `ergaenzungsbox_boden.png` (Unterseite mit QR), `ergaenzungsbox_offen.png` (ohne Deckel), `ergaenzungsbox_schnitt.png` (Längsschnitt + Bajonett), `ergaenzungsbox_nim_draufsicht.png` / `…_nim_vorschau.png` (Startstellung).

## Annahmen (ungetestet)
- Streichhölzer 2,1 × 2,1 × 50 mm (Haushaltshölzer). Bei anderen Hölzern `MATCH_L`, `MATCH_S`, `HOLE_D` anpassen.
- Spiel: Hülle und Einsatzteile 0,4, Deckelrand/Kragen 0,3 radial, Nut 0,3 axial / 0,4 radial.
