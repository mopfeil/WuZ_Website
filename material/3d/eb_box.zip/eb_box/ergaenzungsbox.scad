// =====================================================================
//  Ergänzungsbox -- box with bayonet lid for the larger WuZ parts
//  that are not in the Grundausstattung (27.10.2026)
//  v3 (27.10.2026): no longer round. Outline = rectangle as wide as the
//  sleeve + walls, closed at both ends by circle segments; the bayonet
//  (2 lugs, one per end) sits only on these segments. Match compartments
//  moved to the two ends, finger wells replaced by a push hole in the
//  floor, NIM insert follows the outline (rim text on the end arcs).
//  Round v2: v2_rund/
//  QR code HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/X as an inlay in the
//  underside (second colour), next to the push hole: load
//  ergaenzungsbox_unterteil.stl + ergaenzungsbox_qr.stl as ONE object
//  (Bambu "Add part": ergaenzungsbox_qr_teil.stl).
//  Lettering (31.10.2026): "Wissenschaft / und / Zauberkunst" + a frame
//  following the outline, TXT_DEPTH deep in the lid top, second colour,
//  same scheme as the Grundausstattung lid: ergaenzungsbox_deckel.stl +
//  ergaenzungsbox_schrift.stl as ONE object (Bambu "Add part":
//  ergaenzungsbox_schrift_teil.stl). Reads from above with the lid closed.
//  v2 (27.10.2026): body 5 mm higher (EXTRA_H) so that all matches fit
//  (82 on the NIM board + 15 to play); the tray floor is 5 mm thicker.
//  v1 (30.3 mm high): v1_30mm/
// ---------------------------------------------------------------------
//  Holds
//    * Brett der Wunder v4.1 in its sleeve (88.8 x 85 x 8.8, rubber band
//      on it) flat on the floor, in a square shaft in the middle
//    * on top of it a tray (einsatz) with pockets for the inverter V9
//      (D 48.5 x 9.1), the ball box (D 17 x 4.8) and the Brett QR plate
//      with the coin pressed in (44.1 x 25, coin sticks out 2.6)
//    * matches in the two circle segments at the ends of the shaft (they
//      lie across, along y); push hole PUSH_D in the floor to lift sleeve
//      and tray out from below
//    * small NIM-KI in the lid: a separate insert plate (nim_einsatz)
//      sits on the inside of the lid plate. Matches are stuck into the
//      holes instead of printed pins (one hole per bead of the paper
//      version, 2 per row at the start). To play, take the lid off and
//      put it down upside down: the insert lies face up, the lid skirt
//      is a rim around it. Before closing, put the matches back into
//      their compartments.
//
//  Bayonet: two lugs on the outside of the body collar on a pitch
//  circle (one on each end segment), matching L-grooves on the inside of
//  the lid skirt. The lid skirt exists only on the end segments; along
//  the flat sides the lid wall starts above the body rim, so the lid can
//  turn although the box is not round. Put the
//  lid on with the marks aligned (entry slots over the lugs), press
//  down, turn clockwise (seen from above) by RUN degrees. The run
//  rises by RAMP (pulls the lid down), a small bump DET_H before the
//  end clicks the lug into place.
//
//  Print: body floor on the bed, lid top on the bed (skirt up), insert
//  face up (text = second colour, raised 0.6, same coordinates), tray
//  floor on the bed. No supports (lugs and grooves have 45 deg flanks).
//    openscad -D 'part="unterteil"'  -o ergaenzungsbox_unterteil.stl  ergaenzungsbox.scad
//    openscad -D 'part="qr"'         -o ergaenzungsbox_qr.stl         ergaenzungsbox.scad
//    openscad -D 'part="deckel"'     -o ergaenzungsbox_deckel.stl     ergaenzungsbox.scad
//    openscad -D 'part="nim"'        -o ergaenzungsbox_nim.stl        ergaenzungsbox.scad
//    openscad -D 'part="nim_text"'   -o ergaenzungsbox_nim_text.stl   ergaenzungsbox.scad
//    openscad -D 'part="einsatz"'    -o ergaenzungsbox_einsatz.stl    ergaenzungsbox.scad
//    openscad -D 'part="schrift"'    -o ergaenzungsbox_schrift.stl    ergaenzungsbox.scad
// =====================================================================

/* [Selection] */
part = "baugruppe"; // [baugruppe, schnitt, offen, unterteil, qr, deckel, schrift, deckel_oben, nim, nim_text, einsatz, nim_vorschau]

/* [Contents] */
HUELLE  = [88.8, 85.0, 8.8];   // Brett der Wunder in its sleeve (x, y, height)
INV     = [48.5, 9.1];         // inverter V9: diameter, height
KUGEL   = [17.0, 4.8];         // ball box with cap: diameter, height
QRP     = [44.1, 25.0, 2.4];   // Brett QR plate (coin pressed in)
COIN_UP = 2.6;                 // coin sticks out of the plate (5.0 - 2.4)
MATCH_L = 50;                  // match length (household matches, assumed)
MATCH_S = 2.1;                 // match cross-section (square, assumed)
CLR     = 0.4;                 // play around sleeve and tray items

/* [Box] */
FLOOR   = 1.6;
WALL_I  = 1.2;      // inner walls
COL_W   = 2.0;      // collar wall (lugs on its outside)
BAY_H   = 9.0;      // collar height = lid skirt overlap
SEAM    = 0.3;      // gap lid skirt / body shoulder
CHAMFER = 0.8;
SIDE_W  = 1.6;      // flat side walls (body and lid)
PUSH_D  = 25;       // push hole in the floor (lift sleeve + tray from below)
N_NEED  = 97;       // matches to store (82 on the board + 15 to play)
EXTRA_H = 5;        // extra height for the match compartments (v2); taken up by the tray floor

/* [Tray] */
TR_FLOOR = 1.0;
TR_WALL  = 1.2;
TR_CLR   = 0.3;     // tray in the shaft, per side

/* [Bayonet] */
N_LUG   = 2;        // one per end segment
LUG_R   = 1.2;      // radial height of a lug
LUG_T   = 1.2;      // axial width at the lug tip (45 deg flanks below/above)
LUG_A   = 12;       // arc length of a lug (mm, on the collar)
LUG_Z   = -4.5;     // lug centre below the rim
RUN     = 30;       // turning angle to close
RAMP    = 0.4;      // axial rise along the run
G_CLR_A = 0.3;      // groove play axial (per side)
G_CLR_R = 0.4;      // groove play radial
SL_CLR  = 1.0;      // entry slot wider than the lug (deg, per side)
DET_H   = 0.6;      // detent bump into the groove (interference DET_H - G_CLR_R)
DET_A   = 5;        // bump this many degrees before the end of the run
SK_CLR  = 0.3;      // radial play skirt / collar
SK_W    = 1.6;      // skirt wall behind the groove

/* [Lid + NIM insert] */
LID_TOP  = 1.6;
INS_T    = 6.0;     // insert thickness = hole depth for the matches
INS_GAP  = 0.4;     // gap insert text / body rim
INLAY    = 0.6;     // raised text on the insert
INS_CLR  = 0.25;    // insert in the lid, radial
RIB      = 0.4;     // 4 crush ribs on the flat insert edges (interference RIB - INS_CLR)
HOLE_D   = 3.2;     // match hole (square match 2.1 -> diagonal 3.0)
H_PITCH  = 4.0;     // hole pitch in a row
R_PITCH  = 5.5;     // row pitch
CW       = 27;      // NIM cell width
CH       = 19;      // NIM cell height
NIM_ROWS = [3, 4, 4, 3];      // cells per row, 15..2 in reading order
LINE     = 0.8;     // cell border lines (text colour)
NFONT    = "Roboto Condensed:style=Bold";
MFONT    = "Liberation Mono:style=Bold";   // rim text, fixed advance 0.6 em
RIM_SZ   = 3.4;
RIM_TOP  = "NIM-KI · 15 Hölzchen · nimm 1, 2 oder 3";
RIM_BOT  = "Wer das letzte Hölzchen nimmt, verliert";

/* [Lettering on the lid] */
TXT_ON    = true;
TXT       = ["Wissenschaft", "und", "Zauberkunst"];
TXT_SIZE  = [13, 8.5, 13];    // text() size per line
TXT_Y     = [17.5, 0, -17.5];     // line centres
TXT_FONT  = "Roboto Condensed:style=Bold";
TXT_DEPTH = 0.6;              // inlay depth (3 layers of 0.2)
FRAME_ON  = true;             // frame line following the outline
FRAME_IN  = 5.0;              // frame centre this far inside the outer edge
FRAME_W   = 0.8;

/* [QR code in the floor] */
QR_ON    = true;
QR_MOD   = 1.2;        // module size (25 modules -> 30 mm)
QR_DEPTH = 0.6;        // inlay depth (3 layers of 0.2)
QR_GAP   = 3;          // distance to the push hole
// HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/X, version 2-M (segno), alphanumeric
// (upper case, HTTP so 38 characters fit). Row 0 = top, "1" = dark module.
QR = [
    "1111111010011101001111111",
    "1000001001001000101000001",
    "1011101011010101001011101",
    "1011101001000011001011101",
    "1011101001100101101011101",
    "1000001011000101101000001",
    "1111111010101010101111111",
    "0000000001001000000000000",
    "1010001101001011000100101",
    "1111000111100101010011001",
    "1001101010101001100110101",
    "0110110000101101110001101",
    "1000111010001111111010010",
    "0011000011000100010100101",
    "1110011000011011001000110",
    "0010000000101001101111110",
    "1110111110001110111110011",
    "0000000011111010100011111",
    "1111111010000010101010111",
    "1000001001011111100011011",
    "1011101001101101111110011",
    "1011101001110010101100110",
    "1011101010101101001100011",
    "1000001000101001011011001",
    "1111111010110011101011111"
];

/* [Knurl] */
KNURL_N = 90;
KNURL_R = 1.0;

$fn = 160;
EPS = 0.01;

// ---------- derived values ----------
SH_X  = HUELLE[0]/2 + CLR;                 // square shaft, half sizes
SH_Y  = HUELLE[1]/2 + CLR;
TR_X  = 2*(SH_X - TR_CLR);                 // tray outer size
TR_Y  = 2*(SH_Y - TR_CLR);
TR_H  = TR_FLOOR + EXTRA_H + INV[1] + CLR;
INV_Z = TR_H - INV[1] - CLR;               // inverter pocket floor
WELL_H = HUELLE[2] + CLR + TR_H + CLR;
HW_O  = SH_Y + SIDE_W;                     // half width of the box (flat sides)
// match compartments at both ends, beyond x = X0; matches lie along y and
// need a chord of MATCH_L. R_IN = smallest radius that stores N_NEED
// (packing 0.65), at least the shaft corners.
X0     = SH_X + WALL_I;
D_NEED = N_NEED*MATCH_S*MATCH_S/(2*WELL_H*0.65);
R_IN  = max(ceil(sqrt(SH_X*SH_X + SH_Y*SH_Y)*10)/10 + 0.3,
            ceil(sqrt(pow(X0 + D_NEED, 2) + MATCH_L*MATCH_L/4)*10)/10);
R_COL = R_IN + COL_W;                      // collar outside
R_LT  = R_COL + LUG_R;                     // lug tip
R_SK  = R_COL + SK_CLR;                    // skirt inside
R_GT  = R_LT + G_CLR_R;                    // groove bottom
R_OUT = R_GT + SK_W;                       // outside of body and lid
Z_SH  = -BAY_H;                            // body shoulder
Z_BOT = -WELL_H - FLOOR;
Z_INS = INS_GAP + INLAY;                   // insert underside (= board face, lid upside down)
Z_TOP = Z_INS + INS_T + LID_TOP;
R_INS = R_SK - INS_CLR;
LUG_DEG = LUG_A/R_COL*180/PI;
LUG_ANG = RUN/2;                           // closed lug position: run centred on the x axis
ARC_DEG = asin(HW_O/R_SK);                 // half angle of the end segments at the skirt
SLOT_DEG = LUG_DEG + 2*SL_CLR;
HW_INS = HW_O - SIDE_W - INS_CLR;          // insert half width
QR_X  = PUSH_D/2 + QR_GAP + len(QR)*QR_MOD/2;   // QR centre, +x of the push hole
X_MAX = sqrt(R_IN*R_IN - MATCH_L*MATCH_L/4);
N_MATCH = floor(2*(X_MAX - X0)*WELL_H*0.65/(MATCH_S*MATCH_S));   // both compartments
echo(R_IN = R_IN, length = 2*R_OUT, width = 2*HW_O, total_h = Z_TOP - Z_BOT, well_h = WELL_H,
     match_depth = R_IN - X0, matches_approx = N_MATCH, arc_half_angle = ARC_DEG);
assert(2*SH_Y >= MATCH_L + 2, "match compartment too narrow");
assert(!QR_ON || QR_X + len(QR)*QR_MOD/2 < R_OUT - CHAMFER - 3, "QR code reaches the chamfer");
assert(!QR_ON || QR_DEPTH < FLOOR - 0.6, "QR inlay too deep for the floor");
assert(!TXT_ON || TXT_DEPTH < LID_TOP - 0.6, "lettering too deep for the lid plate");
assert(LUG_ANG + LUG_DEG/2 + SL_CLR + 3 < ARC_DEG && RUN - LUG_ANG + SLOT_DEG/2 + 3 < ARC_DEG,
       "bayonet groove does not fit on the end segment");

// ===================================================================
//  helpers
// ===================================================================
// outline: circle r cut to |y| <= hw (rectangle with circle-segment ends)
module shape2d(r, hw) intersection() { circle(r = r); square([2*r + 2, 2*hw], center = true); }
// prism of that outline, chamfer cb at the bottom, ct at the top (convex -> hull)
module cprism(z0, h, r, hw, cb = 0, ct = 0) hull() {
    translate([0, 0, z0]) linear_extrude(EPS) shape2d(r - cb, hw - cb);
    translate([0, 0, z0 + cb]) linear_extrude(h - cb - ct) shape2d(r, hw);
    translate([0, 0, z0 + h - EPS]) linear_extrude(EPS) shape2d(r - ct, hw - ct);
}
// knurl only on the end arcs (clear of the flat sides)
module knurl(z0, h, n = KNURL_N, r = KNURL_R)
    for (k = [0:n-1]) let(a = 360*k/n) if (abs(sin(a))*(R_OUT + r) + r < HW_O - 1.5)
        rotate([0, 0, a]) translate([R_OUT + r/2, 0, z0 - 1]) cylinder(h = h + 2, r = r, $fn = 20);

// lug cross-section in the r/z plane, base slightly inside the collar
module lug_prof() {
    r0 = R_COL - 0.5; hw = LUG_T/2 + LUG_R + 0.5;
    polygon([[r0, -hw], [R_LT, -LUG_T/2], [R_LT, LUG_T/2], [r0, hw]]);
}
// groove cross-section (lug + play), base inside the skirt wall
module groove_prof() {
    r0 = R_SK - 0.5; tw = LUG_T/2 + G_CLR_A; hw = tw + (R_GT - r0);
    polygon([[r0, -hw], [R_GT, -tw], [R_GT, tw], [r0, hw]]);
}
module slice(a, z, da = 0.5) rotate([0, 0, a]) translate([0, 0, z]) rotate_extrude(angle = da, $fn = 720) groove_prof();

module lug() rotate([0, 0, -LUG_DEG/2]) translate([0, 0, LUG_Z]) rotate_extrude(angle = LUG_DEG, $fn = 720) lug_prof();
module lugs() for (k = [0:N_LUG-1]) rotate([0, 0, 360*k/N_LUG + LUG_ANG]) lug();

// one L-groove in the lid frame; closed position of its lug at angle 0
module groove() {
    a0 = -RUN - SLOT_DEG/2;                       // entry slot (lid frame)
    z0 = LUG_Z - RAMP;
    difference() {
        union() {
            // entry slot from the skirt edge up to the run
            hw = LUG_T/2 + G_CLR_A + (R_GT - R_SK);
            rotate([0, 0, a0]) translate([0, 0, Z_SH + SEAM - 1])
                rotate_extrude(angle = SLOT_DEG, $fn = 720)
                    translate([R_SK - 0.5, 0]) square([R_GT - R_SK + 0.5, z0 - (Z_SH + SEAM - 1)]);
            rotate([0, 0, a0]) translate([0, 0, z0]) rotate_extrude(angle = SLOT_DEG, $fn = 720) groove_prof();
            // run with ramp: lid moves down by RAMP while turning
            n = 12;
            for (i = [0:n-1]) hull() {
                slice(-RUN + RUN*i/n - LUG_DEG/2 - SL_CLR, z0 + RAMP*i/n);
                slice(-RUN + RUN*(i+1)/n - LUG_DEG/2 - SL_CLR, z0 + RAMP*(i+1)/n);
            }
            slice(-LUG_DEG/2 - SL_CLR, LUG_Z, LUG_DEG + 2*SL_CLR);   // end pocket, level
        }
        // detent bump on the groove bottom
        rotate([0, 0, -LUG_DEG/2 - DET_A]) translate([R_GT + 1 - DET_H, 0, LUG_Z - 3])
            cylinder(r = 1, h = 6, $fn = 24);
    }
}

// ===================================================================
//  body (rim = z 0)
// ===================================================================
// walls between the shaft and the match compartments at the ends
module inner_walls()
    for (s = [-1, 1]) translate([s > 0 ? SH_X : -SH_X - WALL_I, -SH_Y - EPS, -WELL_H - EPS])
        cube([WALL_I, 2*SH_Y + 2*EPS, WELL_H + EPS]);

module unterteil() {
    h = Z_SH - Z_BOT;
    difference() {
        union() {
            difference() {
                cprism(Z_BOT, h, R_OUT, HW_O, cb = CHAMFER);
                knurl(Z_BOT, h);
            }
            translate([0, 0, Z_SH - EPS]) linear_extrude(-Z_SH + EPS) shape2d(R_COL, HW_O);
            lugs();
        }
        translate([0, 0, -WELL_H]) linear_extrude(WELL_H + 1) shape2d(R_IN, SH_Y);
        hull() {
            translate([0, 0, -0.4]) linear_extrude(EPS) shape2d(R_IN, SH_Y);
            translate([0, 0, 0]) linear_extrude(EPS) shape2d(R_IN + 0.4, SH_Y + 0.4);
        }
        translate([0, 0, Z_BOT - 1]) cylinder(h = FLOOR + 2, d = PUSH_D);
        if (QR_ON) translate([0, 0, Z_BOT - 1]) linear_extrude(QR_DEPTH + 1) qr_2d();
        // marks on the shoulder: lug positions (line up with the lid marks)
        for (k = [0:N_LUG-1]) rotate([0, 0, 360*k/N_LUG + LUG_ANG])
            translate([R_OUT - 0.6, -0.6, Z_SH - 4]) cube([1, 1.2, 4 + EPS]);
    }
    inner_walls();
}

// QR code, mirrored (x -> -x) about its own centre so it reads correctly
// when the box is turned over
module qr_2d() {
    n = len(QR);
    translate([QR_X, 0]) mirror([1, 0, 0])
        for (r = [0:n-1]) for (c = [0:n-1])
            if (QR[r][c] == "1")
                translate([(c - n/2)*QR_MOD, (n/2 - 1 - r)*QR_MOD]) square(QR_MOD + 0.002);
}
module qr_inlay() translate([0, 0, Z_BOT]) linear_extrude(QR_DEPTH) qr_2d();

// ===================================================================
//  lid (closed position, same frame as the body)
// ===================================================================
module deckel() {
    z0 = Z_SH + SEAM; h = Z_TOP - z0;
    difference() {
        difference() {
            cprism(z0, h, R_OUT, HW_O, ct = CHAMFER);
            knurl(0, Z_TOP);                        // knurl only above the rim (skirt is thin at the grooves)
        }
        // below the body rim only the skirts on the end arcs remain (r > R_SK),
        // so the lid can turn; above it the cavity for the insert
        translate([0, 0, z0 - 1]) cylinder(h = INS_GAP - z0 + 1, r = R_SK);
        translate([0, 0, INS_GAP - EPS]) linear_extrude(Z_TOP - LID_TOP - INS_GAP + EPS) shape2d(R_SK, HW_O - SIDE_W);
        translate([0, 0, z0 - EPS]) cylinder(h = 0.6, r1 = R_SK + 0.6, r2 = R_SK);
        for (k = [0:N_LUG-1]) rotate([0, 0, 360*k/N_LUG + LUG_ANG]) groove();
        if (TXT_ON) translate([0, 0, Z_TOP - TXT_DEPTH]) linear_extrude(TXT_DEPTH + 1) schrift_2d();
        // marks: entry slot positions, on the skirt edge
        for (k = [0:N_LUG-1]) rotate([0, 0, 360*k/N_LUG + LUG_ANG - RUN])
            translate([R_OUT - 0.6, -0.6, z0 - EPS]) cube([1, 1.2, 4]);
    }
}

// lettering on the lid top (closed lid, reads from above)
module schrift_2d() {
    for (i = [0:len(TXT)-1])
        translate([0, TXT_Y[i]])
            text(TXT[i], size = TXT_SIZE[i], font = TXT_FONT, halign = "center", valign = "center");
    if (FRAME_ON) difference() {
        shape2d(R_OUT - FRAME_IN + FRAME_W/2, HW_O - FRAME_IN + FRAME_W/2);
        shape2d(R_OUT - FRAME_IN - FRAME_W/2, HW_O - FRAME_IN - FRAME_W/2);
    }
}
module schrift_inlay() translate([0, 0, Z_TOP - TXT_DEPTH]) linear_extrude(TXT_DEPTH) schrift_2d();

// ===================================================================
//  NIM insert (2D layout seen from the board face; in the lid it is
//  turned over, see nim_in_lid)
// ===================================================================
function nstate(i) = 15 - i;
function nmoves(n) = min(3, n);
function row_start(r) = r == 0 ? 0 : row_start(r - 1) + NIM_ROWS[r - 1];
// cell origin (lower left), slot index i = 0..13
function cell_pos(i) =
    let(r = max([for (k = [0:len(NIM_ROWS)-1]) if (row_start(k) <= i) k]),
        c = i - row_start(r), n = NIM_ROWS[r])
    [(c - n/2)*CW, (len(NIM_ROWS)/2 - 1 - r)*CH];
function hole_pos(i, m, j) = cell_pos(i) + [12 + j*H_PITCH, CH - 4 - m*R_PITCH];

module nim_holes_2d()
    for (i = [0:13]) for (m = [0:nmoves(nstate(i))-1]) for (j = [0:3])
        translate(hole_pos(i, m, j)) circle(d = HOLE_D, $fn = 24);

module nim_outline_2d() {
    difference() {
        union() {
            shape2d(R_INS, HW_INS);
            for (s = [-1, 1], t = [-1, 1]) translate([s*35, t*HW_INS]) circle(r = RIB, $fn = 16);
        }
        // fingernail notch to lift the insert out of the lid
        translate([-5, -HW_INS - 1.4]) square([10, 3]);
    }
}

module arc_text(s, r, a_mid, top) {
    adv = 0.6*RIM_SZ;                          // monospace advance
    n = len(s); da = adv/r*180/PI;
    for (k = [0:n-1]) {
        a = top ? a_mid + (n/2 - k - 0.5)*da : a_mid - (n/2 - k - 0.5)*da;
        rotate(a) translate([r, 0]) rotate(top ? -90 : 90)
            text(s[k], size = RIM_SZ, font = MFONT, halign = "center", valign = "baseline");
    }
}

module nim_text_2d() {
    for (i = [0:13]) {
        p = cell_pos(i);
        translate(p + [3.4, CH/2]) text(str(nstate(i)), size = 4.6, font = NFONT, halign = "center", valign = "center");
        for (m = [0:nmoves(nstate(i))-1])
            translate(hole_pos(i, m, 0) + [-3.4, 0]) text(str(m + 1), size = 3, font = NFONT, halign = "center", valign = "center");
        translate(p) difference() {
            translate([-LINE/2, -LINE/2]) square([CW + LINE, CH + LINE]);
            translate([LINE/2, LINE/2]) square([CW - LINE, CH - LINE]);
        }
    }
    arc_text(RIM_TOP, R_INS - 5.0, 0, true);      // on the end arcs
    arc_text(RIM_BOT, R_INS - 2.0, 180, false);
}

module nim() linear_extrude(INS_T) difference() { nim_outline_2d(); nim_holes_2d(); }
module nim_text() translate([0, 0, INS_T]) linear_extrude(INLAY) difference() { nim_text_2d(); nim_holes_2d(); }

// insert in the closed lid: board face down, mirrored about x
module nim_in_lid(text = true) translate([0, 0, Z_INS + INS_T]) rotate([180, 0, 0]) {
    nim(); if (text) nim_text();
}

// ===================================================================
//  tray (floor = z 0)
// ===================================================================
INV_C = [-TR_X/2 + TR_WALL + INV[0]/2 + CLR, 0];
STRIP = [INV_C[0] + INV[0]/2 + CLR + TR_WALL, TR_X/2 - TR_WALL];   // x range right of the inverter
QR_C  = [(STRIP[0] + STRIP[1])/2, TR_Y/2 - TR_WALL - (QRP[0] + 2*CLR)/2];
KB_C  = [QR_C[0], QR_C[1] - (QRP[0] + 2*CLR)/2 - TR_WALL - (KUGEL[0] + 2*CLR)/2];
assert(STRIP[1] - STRIP[0] >= QRP[1] + 2*CLR, "QR plate does not fit next to the inverter");
assert(KB_C[1] - KUGEL[0]/2 - CLR >= -TR_Y/2 + TR_WALL, "ball box does not fit");

module einsatz() {
    difference() {
        translate([-TR_X/2, -TR_Y/2, 0]) cube([TR_X, TR_Y, TR_H]);
        translate([INV_C[0], INV_C[1], INV_Z]) cylinder(h = TR_H, d = INV[0] + 2*CLR);
        // finger slot at the inverter (tilt it out)
        translate([-TR_X/2 - 1, -8, INV_Z]) cube([INV_C[0] + TR_X/2 + 1, 16, TR_H]);
        // QR plate: plate depth, the coin then ends just below the top
        translate([QR_C[0] - QRP[1]/2 - CLR, QR_C[1] - QRP[0]/2 - CLR, TR_H - QRP[2] - COIN_UP - 0.2])
            cube([QRP[1] + 2*CLR, QRP[0] + 2*CLR, TR_H]);
        translate([KB_C[0], KB_C[1], TR_H - KUGEL[1] - CLR]) cylinder(h = TR_H, d = KUGEL[0] + 2*CLR);
        // spare pocket below the ball box (rubber bands, spare matches)
        translate([STRIP[0], -TR_Y/2 + TR_WALL, TR_H - 5.4])
            cube([STRIP[1] - STRIP[0], KB_C[1] - KUGEL[0]/2 - CLR - TR_WALL - (-TR_Y/2 + TR_WALL), 6]);
    }
}

// ===================================================================
//  contents (preview only)
// ===================================================================
module inhalt() {
    zf = -WELL_H;
    color("DarkSlateGray") translate([-HUELLE[0]/2, -HUELLE[1]/2, zf]) cube(HUELLE);
    translate([0, 0, zf + HUELLE[2] + CLR]) {
        color("Wheat") einsatz();
        translate([INV_C[0], INV_C[1], INV_Z]) color("SteelBlue") cylinder(h = INV[1], d = INV[0]);
        translate([QR_C[0] - QRP[1]/2, QR_C[1] - QRP[0]/2, TR_H - QRP[2] - COIN_UP]) color("White") cube([QRP[1], QRP[0], QRP[2]]);
        translate([KB_C[0], KB_C[1], TR_H - KUGEL[1] - CLR]) color("SeaGreen") cylinder(h = KUGEL[1], d = KUGEL[0]);
    }
    // a few matches in each compartment
    for (s = [-1, 1]) for (k = [0:4]) for (l = [0:2])
        color("BurlyWood") translate([s*(X0 + 1 + k*2.3) - (s < 0 ? MATCH_S : 0), -MATCH_L/2, zf + l*2.3])
            cube([MATCH_S, MATCH_L, MATCH_S]);
}

module half(cut) {
    if (cut) difference() { children(); translate([-300, 0, -300]) cube(600); }
    else children();
}

module baugruppe(cut = false) {
    color("Tan") half(cut) unterteil();
    if (QR_ON) color("Black") half(cut) qr_inlay();
    color("DarkSeaGreen", cut ? 1 : 0.45) half(cut) deckel();
    if (TXT_ON) color("Black") half(cut) schrift_inlay();
    half(cut) { color("Ivory") nim_in_lid(false); color("Black") translate([0, 0, Z_INS + INS_T]) rotate([180, 0, 0]) nim_text(); }
    inhalt();
}

// ---------- output ----------
module lid_print() rotate([180, 0, 0]) translate([0, 0, -Z_TOP]) deckel();
module schrift_print() rotate([180, 0, 0]) translate([0, 0, -Z_TOP]) schrift_inlay();

if (part == "unterteil") translate([0, 0, -Z_BOT]) unterteil();
else if (part == "qr") translate([0, 0, -Z_BOT]) qr_inlay();
else if (part == "deckel") lid_print();
else if (part == "schrift") schrift_print();
else if (part == "deckel_oben") { color("DarkSeaGreen") deckel(); if (TXT_ON) color("Black") schrift_inlay(); }
else if (part == "nim") nim();
else if (part == "nim_text") nim_text();
else if (part == "einsatz") einsatz();
else if (part == "baugruppe") baugruppe();
else if (part == "schnitt") baugruppe(cut = true);
else if (part == "offen") { color("Tan") unterteil(); inhalt(); }
else if (part == "nim_vorschau") {
    color("Ivory") nim(); color("Black") nim_text();
    // start position: 2 matches per row
    for (i = [0:13]) for (m = [0:nmoves(nstate(i))-1]) for (j = [0:1])
        translate(concat(hole_pos(i, m, j), [INS_T])) {
            color("BurlyWood") translate([-MATCH_S/2, -MATCH_S/2, -INS_T + 0.2]) cube([MATCH_S, MATCH_S, MATCH_L - 4]);
            color("Firebrick") translate([0, 0, MATCH_L - INS_T - 4]) scale([1, 1, 1.4]) sphere(d = 3.2, $fn = 16);
        }
}
