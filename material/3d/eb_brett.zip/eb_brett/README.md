# Brett der Wunder v4: Basisplatte mit Raster, Beschriftungsring, Kacheln (18.10.2026, v4 23.10.2026, v4.1 26.10.2026)

**v4.2 (01.11.2026): Druckhilfe für die stehende Hülle.** Beim Druck rutschte die Hülle vom Bett, weil sie 85 hoch ist und nur auf 88,8 × 8,8 steht. Neu ist eine **Stütze** (`huelle_stuetze.stl`). Sie besteht aus einer Fußplatte 134,4 × 54,4 × 0,6 und **6 Stützrippen** (2 dick, 45 hoch, 22 Ausladung): je 2 an den breiten Seiten bei x = ±30 (weit genug weg von den Kerben) und je 1 an den Stirnseiten. Zwischen Rippe und Hülle bleiben 0,8 mm. Diese Lücke wird in **6 Bändern** (je 1,2 hoch, alle 8 mm, bis z = 41,2) mit **Supportfilament** gefüllt (`huelle_stuetze_kontakt.stl`). Die Rippen umschließen die Hülle von allen vier Seiten. Die Bänder müssen also nicht kleben, sie übertragen nur Druck. Das Supportfilament kommt nur in rund 36 Schichten vor, so bleibt es bei wenigen Filamentwechseln. Die Hülle selbst ist unverändert und steht weiter direkt auf dem Bett. Bambu-Projekt: `huelle_mit_stuetze.3mf`, ein Objekt mit drei Teilen (Hülle und Stütze Filament 1, Kontaktbänder **Filament 2 = Support for PLA** wie in Markus’ X2D-Projekten). Nach dem Druck die Rippen abbrechen. Vorschau `huelle_stuetze_Vorschau.png`. Parameter `ST_*` im SCAD. Ungetestet.

**v4.1 (26.10.2026):** Neu ist eine **Hülle** (`huelle.stl`), in die das zusammengesetzte Brett (Basis + Ring + Kacheln, 85 × 85 × 6,0) genau hineinpasst. Spiel: 0,3 je Seite in der Breite, 0,4 über den Kacheln. Die Deckplatte liegt auf den Kacheln auf und hält sie in den Taschen. Die Hülle ist außen 88,8 × 85 × 8,8 (Wände 1,6, Deck- und Bodenplatte 1,2) und vorn und hinten offen. Das Brett schließt an beiden Enden bündig ab. An beiden Enden sitzt oben und unten eine **Kerbe** (22 breit, 9 tief, 45°-Flanken). Dort fasst der Finger an, um das Brett herauszuschieben, und dort liegt auch ein **Gummi**, der der Länge nach um die Hülle läuft. Er geht über beide offenen Enden, so dass nichts herausrutscht. **Gedruckt wird die Hülle stehend** auf einem offenen Ende (STL schon so ausgerichtet, 85 hoch). Die einzige Brücke ist das 4 mm breite Kerbende, Stützen sind nicht nötig. Weil die Standfläche schmal ist, empfiehlt sich ein Brim. Die **Figur ist jetzt eine dicke Münze** (Ø 16 × 5, Fasen 0,6) mit einem **Schlitz** quer über die Oberseite (4 breit, 1,6 tief) für den Gummi. Sie liegt außen auf der Hülle unter dem Gummi. Ins Figurenfach des Zauberkoffers (20 × 23,2 × 14) passt sie weiterhin. In den Deckel des Koffers passt die Hülle nicht (Mulde 85²); dort bleibt das Brett ohne Hülle. Dazu kommt eine **QR-Platte** (`qr_platte.stl` + `qr_platte_qr.stl`, 44,1 × 25 × 2,4). Links hat sie ein Loch Ø 16,1, in das die Münze gedrückt wird, rechts den QR-Code auf **wissenschaftundzauberkunst.de/B** (Seite noch anzulegen; Modul 0,76, 19 mm, als 0,6 tiefe Einlage). Die Münze steht 2,6 über der Platte und liegt auf der Hülle auf. Der Gummi läuft durch den Münzschlitz und drückt auch die Plattenkanten nieder. Wenn das Loch zu stramm oder zu locker ist, `HOLE_D` ändern. Die Platte wird **mit der Sichtseite nach unten** gedruckt, so wie exportiert (QR gespiegelt auf dem Bett, per Render + opencv geprüft). Siehe `huelle_Vorschau.png` und `figur_Vorschau.png`. Bambu-Projekt: `brett_huelle_figur.3mf`. Hülle und Platte nutzen Filament 1 (hell, damit der QR lesbar ist), Münze und QR Filament 2 (dunkel). Ungetestet. v4 mit Bauer und Markus' Bambu-3MF liegt in `v4_bauer/`.

**v4:** Basisplatte 85 × 85 mm. Das 3×3-Raster sitzt jetzt **in der Basisplatte** (Gitterblock 71,4 mm mit Taschen, Stege 2,0, Drückloch Ø 8 unter jedem Feld). Der Rahmen ist nur noch ein **Beschriftungsring** (6,5 breit, 2,6 dick), der um den Gitterblock gelegt wird und außen bündig mit der Basis abschließt. Er bleibt wendbar. Kacheln 20,5 × 20,5 × 4 **nur mit Zahl und Symbol** (keine Namen). Jede Kachel hat unten links (von oben gesehen) einen **Keil-Unterschnitt**: Schenkel 7 mm entlang beider Kanten, an der Ecke 1,2 hoch (13,6°). Drückt man auf diese Ecke, kippt die Kachel, und die Gegenecke hebt sich um bis zu 5,8 mm. Die Kacheln stehen 1,4 mm über Raster und Ring (mehr als die Keilhöhe), so kommt der Finger ganz hinunter. Höhe zusammengesetzt 6,0 (Basis 4,6). v3.1 (29-mm-Kacheln, Raster im Rahmen, Namen) in `v3_1_29mm/`.

**Zauberkoffer:** Ab Koffer v4 (23.10.2026) passt die Deckelmulde für 85 × 85 × 6, mit Abdeckplatte und zwei Drehriegeln (siehe `../zauberkoffer/`).

Die Geschichte stammt aus dem ursprünglichen „Wonder Assessment" (`Wonder Assessment v2 (standalone).html`). Auf dem Brett liegen acht Dinge, mit denen wir die Welt erkennen, und ein Fragezeichen. Nach jedem Zug wird eines fortgenommen: *„Alles Bekannte ist fortgefallen. Nur die Frage bleibt."*
Felder: 1 Linse, 2 Beweis, 3 Stundenglas, 4 Kartenspiel, 5 Kerze, 6 ?, 7 Buch, 8 Kompass, 9 Schlüssel. Wie im Original liegt auf Feld 5 die Kerze, nicht die Kristallkugel aus Studie 4.

## Teile (`brett_der_wunder.scad`)
| STL | Inhalt |
|---|---|
| `basis_body` | Basisplatte 85 × 85, Boden 2,0, darauf Gitterblock 71,4 × 71,4 × 2,6 mit 9 Taschen 21,1 (0,3 Spiel je Seite) und Drücklöchern Ø 8, einfarbig |
| `rahmen_body` + `rahmen_inlay` | Beschriftungsring 85 außen, 0,3 Spiel um den Gitterblock, 2,6 dick. Vorderseite: Zeilen A B C (links), Spalten 1 2 3 (oben). **Wie eine Buchseite um die senkrechte Achse wenden:** dann Spalten A B C (oben), Zeilen 1 2 3 (links). Siehe `rahmen_Rueckseite.png` |
| `kacheln_body` + `kacheln_inlay` | 9 Kacheln mit Zahl und Symbol, Keil unten links (`kachel_Keil.png`). Kachel 6: oben „?", unten „Nur die Frage bleibt.“ (außerhalb des Keils). **Schon umgedreht exportiert** |
| `figur` | Spielfigur: Münze Ø 16 × 5 mit Gummischlitz (v4.1) |
| `qr_platte` + `qr_platte_qr` | QR-Platte /B mit Pressloch für die Münze, Sichtseite unten (v4.1) |
| `huelle` | Hülle für das zusammengesetzte Brett, stehend ausgerichtet (v4.1) |
| `huelle_stuetze` / `huelle_stuetze_kontakt` | Druckhilfe für die stehende Hülle, gleiche Koordinaten; Kontakt in Supportfilament (v4.2) |
| `*_inlay_teil.stl` | Farbteile relativ zur Körpermitte (für „Teil hinzufügen“) |
| `brett_der_wunder_v4.3mf` | Bambu-Projekt, alles auf einer Platte (ungetestet) |

Druck: Basis und Ring mit der Oberseite nach oben (die Einlage der Ringrückseite liegt auf dem Bett). **Kacheln mit der Oberseite nach unten:** Zahl und Symbol liegen auf dem Bett, der Keil oben, keine Stützen nötig.

## Regeln (werden angesagt, nicht gedruckt)
Figur auf ein beliebiges Feld stellen. Schritte gehen orthogonal. Leere Felder darf man überqueren, aber kein Zug darf auf einem leeren Feld enden.
| Zug | 1 | 2 | 3 | 4 | 5 | 6 |
|---|---|---|---|---|---|---|
| Schritte | Zahl des Startfelds | 5 | 2 | 3 | 3 | 1 |
| danach fort | 7 Buch | 4 Kartenspiel | 8 Kompass | 1 Linse + 9 Schlüssel | 2 Beweis | 3 Stundenglas + 5 Kerze |

Jeder Weg endet auf Feld 6 (für alle neun Startfelder nachgerechnet, 22.10.2026). Zum Schluss Kachel 6 umdrehen.
Die v1-Fassung (einteiliges Brett, Kristallkugel) liegt in `v1_einteilig/`. Passungen und Kippmechanik ungetestet.
