// =====================================================================
//  Brett der Wunder v4: base plate with grid + label ring + tiles
//  (18.10.2026, v4 23.10.2026, v4.1 26.10.2026)
//  v4.1 (26.10.2026): sleeve (huelle) the assembled board slides into,
//  open at front and back with a notch top and bottom at each end (finger
//  + rubber band around the length). Pawn replaced by a thick coin with a
//  slot for the band, so it rides on the sleeve under the band.
//  QR plate (qr_platte): also goes under the band; the coin is pressed into
//  its hole, the band runs through the coin slot and holds everything.
//  QR -> HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/B (page still to be made).
//  v4.2 (01.11.2026): print aid for the standing sleeve (it slid off the
//  bed): foot plate + 6 buttress fins (huelle_stuetze, normal filament)
//  that cradle the sleeve; the gap fin <-> sleeve is filled in bands with
//  support filament (huelle_stuetze_kontakt). Sleeve itself unchanged.
//  v4 with pawn: v4_bauer/
//  v4 (23.10.2026): base plate 85 mm wide. The 3x3 grid is now part of
//  the base plate; the reversible ring around it only carries the
//  labels. Tiles show number + icon only (no names) and have a wedge
//  undercut at the bottom left corner: press that corner down and the
//  opposite corner lifts out of the pocket. v3.1 (29 mm tiles, grid in
//  the frame, names): v3_1_29mm/
//  v3.1 (22.10.2026): move table ZUG/FORT removed. v3: v3_zugtafel/,
//  v2 (34 mm tiles): v2_34mm/
// ---------------------------------------------------------------------
//  Story (original "Wonder Assessment", Markus): nine things we know
//  lie on the board - lens, proof, hourglass, deck, candle, book,
//  compass, key - and a question mark. After every move one of them is
//  taken away: "Alles Bekannte ist fortgefallen. Nur die Frage bleibt."
//  Fields 1..9 row by row from top left, moves: number on the start
//  field, 5, 2, 3, 3, 1 steps (orthogonal, empty fields may be crossed,
//  a move must not end on one). Removed: 7 / 4 / 8 / 1+9 / 2 / 3+5,
//  forced end on 6 ("?").
//
//  Parts (colour 2 = inlay 0.6 deep and flush, like the Zener chips):
//  - basis:  floor BW x BW with a raised 3x3 grid block (pockets, push
//            hole under every field); single colour.
//  - rahmen: square label ring around the grid block, flush with the
//            outer edge of the base, fits both ways up.
//            Front: rows A B C (left), columns 1 2 3 (top).
//            Back (turn it over like a book page, about the vertical
//            axis): columns A B C (top), rows 1 2 3 (left).
//  - kacheln: 9 tiles TILE x TILE x TILE_T with number and icon, wedge
//            undercut at the bottom left corner (seen from above).
//            Tile 6: "?" on top, underside "Nur die Frage bleibt".
//  - figur:  thick coin with a slot across the top for the rubber band.
//  - qr_platte (+ qr_platte_qr in colour 2): plate with QR code /B and a
//            press-fit hole for the coin. Print FACE DOWN as exported (QR
//            on the bed, mirrored so it reads correctly).
//  - huelle: sleeve for base + ring + tiles; print STANDING on one open
//            end (no bridges except the 4 mm top of the notch).
//  Tiles stick out PROUD above grid and ring (> WEDGE_H, so the pressed
//  corner can go all the way down).
//
//  Print base and ring face up, tiles FACE DOWN (the kacheln parts are
//  already turned over: top inlay on the bed, wedge on top, no support).
//  The inlay of the ring back lies on the bed. Body + inlay share
//  coordinates.
//    openscad -D 'part="basis"'         -o basis_body.stl    brett_der_wunder.scad
//    openscad -D 'part="rahmen"'        -o rahmen_body.stl   brett_der_wunder.scad
//    openscad -D 'part="rahmen_inlay"'  -o rahmen_inlay.stl  brett_der_wunder.scad
//    openscad -D 'part="kacheln"'       -o kacheln_body.stl  brett_der_wunder.scad
//    openscad -D 'part="kacheln_inlay"' -o kacheln_inlay.stl brett_der_wunder.scad
//    openscad -D 'part="figur"'         -o figur.stl         brett_der_wunder.scad
//    openscad -D 'part="huelle"'        -o huelle.stl        brett_der_wunder.scad
//    openscad -D 'part="huelle_stuetze"'         -o huelle_stuetze.stl         brett_der_wunder.scad
//    openscad -D 'part="huelle_stuetze_kontakt"' -o huelle_stuetze_kontakt.stl brett_der_wunder.scad
//    openscad -D 'part="qr_platte"'     -o qr_platte.stl     brett_der_wunder.scad
//    openscad -D 'part="qr_platte_qr"'  -o qr_platte_qr.stl  brett_der_wunder.scad
//  v1 (one-piece board, crystal ball): v1_einteilig/
// =====================================================================

/* [Selection] */
part = "baugruppe"; // [baugruppe, rueckseite, basis, rahmen, rahmen_inlay, kacheln, kacheln_inlay, kachel, kachel_inlay, figur, huelle, huelle_druck, huelle_stuetze, huelle_stuetze_kontakt, huelle_mit_stuetze, qr_platte, qr_platte_qr, verpackt]
TILE_NO = 1;

/* [Overall] */
BW      = 85.0;    // width of the base plate (= outer edge of the ring)
FLOOR   = 2.0;
PUSH_D  = 8.0;

/* [Grid and ring] */
CLR     = 0.3;     // tile play per side in a pocket
RIB     = 2.0;     // grid walls, also the outer wall of the grid block
FIT     = 0.3;     // ring play per side around the grid block
MARGIN  = 6.5;     // ring width (labels)
LBL_SZ  = 4.2;

/* [Tiles] */
TILE_T  = 4.0;
TILE_R  = 0.8;
PROUD   = 1.4;     // tile top above grid and ring
INLAY   = 0.6;
ICON_S  = 0.75;    // icon scale (strokes 1.2 -> 0.9)
ICON_OFF = [0.6, -0.6];  // icon a little away from the number
Q_SZ    = 12.0;    // "?" on tile 6
T6_SZ   = 3.4;     // underside of tile 6
NUM_SZ  = 3.8;
FONT    = "DejaVu Sans:style=Bold";

/* [Wedge undercut] */
WEDGE_LEG = 7.0;   // along both edges from the (sharp) bottom left corner
WEDGE_H   = 1.2;   // height of the undercut at that corner

/* [Coin (playing piece)] */
COIN_D   = 16.0;
COIN_H   = 5.0;
COIN_CH  = 0.6;    // chamfer top and bottom
SLOT_W   = 4.0;    // slot for the rubber band, across the top
SLOT_D   = 1.6;

/* [Sleeve] */
SL_CLR   = 0.3;    // play per side in width
SL_CLR_H = 0.4;    // play in height (above the tiles)
SL_SIDE  = 1.6;    // side walls
SL_PLATE = 1.2;    // top and bottom plate
NOTCH_W  = 22.0;   // notch width at the open end
NOTCH_D  = 9.0;    // notch depth; 45 deg flanks, flat 4 at the bottom

/* [Print aid for the standing sleeve] */
ST_GAP    = 0.8;   // fin <-> sleeve, filled with support filament in bands
ST_FIN_T  = 2.0;   // fin thickness
ST_FIN_H  = 45.0;  // fin height at the sleeve (sleeve 85)
ST_FIN_OUT = 22.0; // fin reach on the bed
ST_FIN_X  = 30.0;  // fins on the wide faces at x = +-30 (notches |x| < 11)
ST_FOOT_T = 0.6;   // foot plate under the fins
ST_BAND_H = 1.2;   // support filament bands (6 layers of 0.2)
ST_BAND_STEP = 8.0;

/* [QR plate] */
QP_T     = 2.4;    // plate thickness (coin sticks out 2.6, slot stays above the plate)
QP_EDGE  = 3.0;    // margin around hole and QR code (light quiet zone)
QP_GAP   = 3.0;    // between hole and QR code
QP_R     = 3.0;
HOLE_D   = 16.1;   // press fit for the coin (COIN_D 16); printed holes come out a bit small
QR_MOD   = 0.76;   // 25 modules -> 19.0 mm
QR_DEPTH = 0.6;

$fn = 64;
EPS = 0.01;

GRID  = BW - 2*MARGIN - 2*FIT;       // grid block incl. outer walls
OPEN  = (GRID - 4*RIB) / 3;
TILE  = OPEN - 2*CLR;
PITCH = OPEN + RIB;
WALL_H = TILE_T - PROUD;             // grid walls and ring above the floor
BT    = FLOOR + WALL_H;
// wedge: plane through the pivot line, rising towards the corner
W_RUN  = WEDGE_LEG / sqrt(2);        // pivot line -> sharp corner, along the diagonal
W_SLOPE = WEDGE_H / W_RUN;
U0     = TILE / sqrt(2) - W_RUN;     // centre -> pivot line
LIFT   = (U0 + TILE / sqrt(2)) * W_SLOPE;
echo(str("Kachel ", TILE, " x ", TILE, " x ", TILE_T, ", Basis ", BW, " x ", BW, " x ", BT,
         ", Gitterblock ", GRID, ", Ring ", MARGIN, " breit, Keil ", atan(W_SLOPE), " Grad, Hub Gegenecke ", LIFT));

// centre of field n (1..9), origin = plate centre
function cell(n) = let(r = floor((n-1)/3), c = (n-1)%3) [(c-1)*PITCH, (1-r)*PITCH];

// ---- icons (2D, about 16 x 16, strokes >= 1.2 for a 0.4 nozzle) ------
module ring(r, w) { difference() { circle(r); circle(r - w); } }
module bar(a, b, w) { hull() { translate(a) circle(d = w); translate(b) circle(d = w); } }
module card() offset(r = 1) square([7, 11], center = true);
module front_card() translate([2, -0.5]) rotate(-12) card();

module icon(n) {
    if (n == 1) {                          // Linse: magnifying glass
        translate([-2, 2]) ring(5.5, 1.6);
        bar([1.9, -1.9], [6.5, -6.5], 2.4);
    }
    if (n == 2) {                          // Beweis: lines of a proof ending in the q.e.d. tombstone
        for (y = [5.4, 1.4]) translate([-7.5, y]) square([15, 1.4]);
        translate([-7.5, -2.6]) square([8, 1.4]);
        translate([3, -3.6]) square([4.5, 4.5]);
    }
    if (n == 3) {                          // Stundenglas
        translate([0, 7.2]) square([12, 1.6], center = true);
        translate([0, -7.2]) square([12, 1.6], center = true);
        difference() {
            polygon([[-5, 6.4], [5, 6.4], [0.9, 0], [5, -6.4], [-5, -6.4], [-0.9, 0]]);
            polygon([[-3.2, 5], [3.2, 5], [0, 1.4]]);
            polygon([[0, -2.4], [2.4, -5], [-2.4, -5]]);
        }
    }
    if (n == 4) {                          // Kartenspiel: two fanned cards
        difference() {
            translate([-2.5, 0.5]) rotate(12) difference() { card(); offset(r = -1.4) card(); }
            front_card();
        }
        difference() { front_card(); offset(r = -1.4) front_card(); }
        translate([2, -0.5]) rotate(-12) circle(1.6);
    }
    if (n == 5) {                          // Kerze: candle with flame
        translate([-2.5, -7]) square([5, 10]);
        translate([-6, -8.4]) square([12, 1.6]);
        translate([0, 5.6]) hull() { circle(1.8); translate([0, 3.6]) circle(0.3); }
    }
    if (n == 6) {
        text("?", size = Q_SZ, font = FONT, halign = "center", valign = "center");
    }
    if (n == 7) {                          // Buch: open book
        polygon([[-0.8, -5], [-7.5, -3.6], [-7.5, 6.4], [-0.8, 5]]);
        polygon([[0.8, -5], [7.5, -3.6], [7.5, 6.4], [0.8, 5]]);
        polygon([[-8, -6.4], [8, -6.4], [8, -5.4], [0, -5.6], [-8, -5.4]]);
    }
    if (n == 8) {                          // Kompass
        ring(7.5, 1.3);
        polygon([[0, 6], [1.8, 0], [0, -6], [-1.8, 0]]);
    }
    if (n == 9) {                          // Schluessel
        translate([-5, 0]) ring(3.8, 1.6);
        translate([-1.4, -0.8]) square([9.4, 1.6]);
        translate([5, -3.8]) square([1.6, 3]);
        translate([2.2, -3]) square([1.6, 2.2]);
    }
}

module tile_top_2d(n) {
    if (n == 6) icon(6);
    else translate(ICON_OFF) scale(ICON_S) icon(n);
    translate([-TILE/2 + 1.6, TILE/2 - 1.6])
        text(str(n), size = NUM_SZ, font = FONT, halign = "left", valign = "top");
}

// underside of tile 6, mirrored so it reads correctly after turning the tile over;
// kept clear of the wedge (bottom left in model space)
module tile6_bottom_2d() {
    mirror([1, 0]) for (i = [0:2])
        translate([0, 6.2 - i*4.6])
            text(["Nur die", "Frage", "bleibt."][i], size = T6_SZ, font = FONT, halign = "center", valign = "center");
}

module tile_shape() offset(r = TILE_R) square(TILE - 2*TILE_R, center = true);

// everything below the wedge plane at the bottom left corner
module wedge_cut()
    rotate(225) translate([U0, 0, 0]) rotate([0, -atan(W_SLOPE), 0])
        translate([0, -TILE, -TILE]) cube([TILE, 2*TILE, TILE]);

module tile_inlay(n) {
    translate([0, 0, TILE_T - INLAY]) linear_extrude(INLAY) tile_top_2d(n);
    if (n == 6) linear_extrude(INLAY) tile6_bottom_2d();
}
module tile_body(n) {
    difference() {
        linear_extrude(TILE_T) tile_shape();
        wedge_cut();
        translate([0, 0, TILE_T - INLAY]) linear_extrude(INLAY + EPS) tile_top_2d(n);
        if (n == 6) translate([0, 0, -EPS]) linear_extrude(INLAY + EPS) tile6_bottom_2d();
    }
}

// ---- label ring --------------------------------------------------------
LBL_POS = GRID/2 + FIT + MARGIN/2;   // distance of the label line from the centre
module lbl(s) text(s, size = LBL_SZ, font = FONT, halign = "center", valign = "center");

// front: A B C rows on the left, 1 2 3 columns on top
module front_labels_2d() {
    for (i = [0:2]) {
        translate([-LBL_POS, (1-i)*PITCH]) lbl(["A", "B", "C"][i]);
        translate([(i-1)*PITCH, LBL_POS]) lbl(str(i+1));
    }
}
// back as seen after turning over about the vertical axis:
// A B C columns on top, 1 2 3 rows on the left; mirrored into model space
module back_labels_2d() {
    mirror([1, 0]) for (i = [0:2]) {
        translate([(i-1)*PITCH, LBL_POS]) lbl(["A", "B", "C"][i]);
        translate([-LBL_POS, (1-i)*PITCH]) lbl(str(i+1));
    }
}

module plate_outline() offset(r = 3) offset(delta = -3) square(BW, center = true);
module grid_outline()  offset(r = 1.5) offset(delta = -1.5) square(GRID, center = true);
module rahmen_body() {
    difference() {
        linear_extrude(WALL_H) difference() { plate_outline(); offset(delta = FIT) grid_outline(); }
        translate([0, 0, WALL_H - INLAY]) linear_extrude(INLAY + EPS) front_labels_2d();
        translate([0, 0, -EPS]) linear_extrude(INLAY + EPS) back_labels_2d();
    }
}
module rahmen_inlay() {
    translate([0, 0, WALL_H - INLAY]) linear_extrude(INLAY) front_labels_2d();
    linear_extrude(INLAY) back_labels_2d();
}

// ---- base plate (origin = plate centre) ---------------------------------
module basis_body() {
    difference() {
        union() {
            linear_extrude(FLOOR) plate_outline();
            linear_extrude(BT) grid_outline();
        }
        for (n = [1:9]) translate([cell(n)[0], cell(n)[1], 0]) {
            translate([0, 0, FLOOR]) linear_extrude(BT)
                offset(r = TILE_R) square(OPEN - 2*TILE_R, center = true);
            translate([0, 0, -EPS]) cylinder(d = PUSH_D, h = FLOOR + 2*EPS);
        }
    }
}

// playing piece: thick coin, slot across the top holds the rubber band
module coin() {
    difference() {
        rotate_extrude() polygon([[0, 0], [COIN_D/2 - COIN_CH, 0], [COIN_D/2, COIN_CH],
                                  [COIN_D/2, COIN_H - COIN_CH], [COIN_D/2 - COIN_CH, COIN_H], [0, COIN_H]]);
        // slot with small 45 deg lead-in at the top edge
        translate([0, 0, COIN_H - SLOT_D]) linear_extrude(SLOT_D + EPS) square([COIN_D + 1, SLOT_W], center = true);
        translate([0, 0, COIN_H]) rotate([0, 90, 0]) linear_extrude(COIN_D + 1, center = true)
            polygon([[EPS, -SLOT_W/2 - 0.5], [EPS, SLOT_W/2 + 0.5], [-0.5, SLOT_W/2], [-0.5, -SLOT_W/2]]);
    }
}

// ---- QR plate: coin hole left, QR code right (seen from the visible side) ----
// QR: HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/B, version 2-M, alphanumeric
QR_B = [
    "1111111011101100101111111",
    "1000001001111110101000001",
    "1011101001010011001011101",
    "1011101011001010101011101",
    "1011101011100100001011101",
    "1000001011110011101000001",
    "1111111010101010101111111",
    "0000000011111001100000000",
    "1000101111011010111111001",
    "0010010011011011011101000",
    "1100011100111111101000100",
    "1001100101001100000000011",
    "0000001001011110001011100",
    "1111110110101010011010100",
    "0011111001000101000110111",
    "0001000110001000011110000",
    "1101011001001111111111101",
    "0000000011110100100011110",
    "1111111011001100101010110",
    "1000001001101110100010101",
    "1011101010011100111111101",
    "1011101000011100100010111",
    "1011101001000011000010010",
    "1000001000011000101010111",
    "1111111010000010011010001"
];
QR_S  = len(QR_B)*QR_MOD;
QP_W  = 2*QP_EDGE + HOLE_D + QP_GAP + QR_S;
QP_H  = 2*QP_EDGE + max(HOLE_D, QR_S);
QP_HX = -QP_W/2 + QP_EDGE + HOLE_D/2;     // hole centre (visible side)
QP_QX =  QP_W/2 - QP_EDGE - QR_S/2;       // QR centre (visible side)
echo(str("QR-Platte ", QP_W, " x ", QP_H, " x ", QP_T, ", QR ", QR_S));
// model space: visible face on the bed (z = 0), everything mirrored in x
module qp_qr_2d() {
    n = len(QR_B);
    mirror([1, 0]) translate([QP_QX, 0])
        for (r = [0:n-1], c = [0:n-1]) if (QR_B[r][c] == "1")
            translate([(c - n/2)*QR_MOD, (n/2 - 1 - r)*QR_MOD]) square(QR_MOD + 0.002);
}
module qr_platte() {
    difference() {
        linear_extrude(QP_T) offset(r = QP_R) square([QP_W - 2*QP_R, QP_H - 2*QP_R], center = true);
        translate([-QP_HX, 0, -1]) cylinder(d = HOLE_D, h = QP_T + 2);
        // 0.4 lead-in on the back (coin goes in from there)
        translate([-QP_HX, 0, QP_T - 0.4]) cylinder(d1 = HOLE_D, d2 = HOLE_D + 0.8 + EPS, h = 0.4 + EPS);
        translate([0, 0, -1]) linear_extrude(QR_DEPTH + 1) qp_qr_2d();
    }
}
module qr_platte_qr() linear_extrude(QR_DEPTH) qp_qr_2d();

// ---- sleeve: tube along y, open at both ends ----------------------------
STACK_H = FLOOR + TILE_T;            // base floor + tiles sticking out
SL_IW = BW + 2*SL_CLR;
SL_IH = STACK_H + SL_CLR_H;
SL_OW = SL_IW + 2*SL_SIDE;
SL_OH = SL_IH + 2*SL_PLATE;
SL_L  = BW;                          // board flush with both open ends
echo(str("Huelle aussen ", SL_OW, " x ", SL_L, " x ", SL_OH, ", innen ", SL_IW, " x ", SL_IH));

module notch_2d()                    // in x/y, opening at y = 0, going into +y
    polygon([[-NOTCH_W/2, -EPS], [NOTCH_W/2, -EPS],
             [NOTCH_W/2 - NOTCH_D, NOTCH_D], [-NOTCH_W/2 + NOTCH_D, NOTCH_D]]);
module huelle() {                    // origin: centre of the bottom face, length along y
    difference() {
        translate([-SL_OW/2, -SL_L/2, 0]) cube([SL_OW, SL_L, SL_OH]);
        translate([-SL_IW/2, -SL_L/2 - 1, SL_PLATE]) cube([SL_IW, SL_L + 2, SL_IH]);
        // 0.6 lead-in chamfer at both openings
        for (e = [-1, 1]) translate([0, e*SL_L/2, SL_PLATE + SL_IH/2]) hull() {
            cube([SL_IW + 1.2, 2*EPS + 0.02, SL_IH + 1.2], center = true);
            cube([SL_IW, 1.2, SL_IH], center = true);
        }
        // notches through top and bottom plate at both ends
        for (e = [-1, 1]) translate([0, e*SL_L/2, -1]) mirror([0, e > 0 ? 1 : 0, 0])
            linear_extrude(SL_OH + 2) notch_2d();
    }
}

// ---- print aid for the sleeve standing on one open end -------------
// Same coordinates as part "huelle_druck": footprint x +-SL_OW/2,
// y +-SL_OH/2, z 0..SL_L. Fins cradle the sleeve on all four sides; the
// support-filament bands only transmit pressure, they need not stick.
ST_X = SL_OW/2 + ST_GAP;             // inner edge of the fins
ST_Y = SL_OH/2 + ST_GAP;
module st_fin()                      // at origin, reaching into +y, thickness along x
    translate([-ST_FIN_T/2, 0, 0]) rotate([90, 0, 90]) linear_extrude(ST_FIN_T)
        polygon([[0, 0], [ST_FIN_OUT, 0], [ST_FIN_OUT, ST_FOOT_T], [0, ST_FIN_H]]);
// fin placements: [x, y, angle]
ST_FINS = [for (sx = [-1, 1], sy = [-1, 1]) [sx*ST_FIN_X, sy*ST_Y, sy > 0 ? 0 : 180],
           [ ST_X, 0, -90], [-ST_X, 0, 90]];
module huelle_stuetze() {
    for (f = ST_FINS) translate([f[0], f[1], 0]) rotate(f[2]) st_fin();
    linear_extrude(ST_FOOT_T) difference() {
        offset(r = 3) offset(delta = -3)
            square([2*(ST_X + ST_FIN_OUT), 2*(ST_Y + ST_FIN_OUT)], center = true);
        square([2*ST_X, 2*ST_Y], center = true);
    }
}
ST_NB = floor((ST_FIN_H - 3 - ST_BAND_H) / ST_BAND_STEP) + 1;
module huelle_stuetze_kontakt()
    for (f = ST_FINS, k = [0:ST_NB-1]) translate([f[0], f[1], k*ST_BAND_STEP]) rotate(f[2])
        translate([-ST_FIN_T/2, -ST_GAP, 0]) cube([ST_FIN_T, ST_GAP, ST_BAND_H]);
echo(str("Stuetze: ", ST_NB, " Kontaktbaender bis z = ", (ST_NB-1)*ST_BAND_STEP + ST_BAND_H,
         ", Fuss ", 2*(ST_X + ST_FIN_OUT), " x ", 2*(ST_Y + ST_FIN_OUT)));

// print layout: tiles turned over (top inlay on the bed, wedge on top)
TP = TILE + 4;
module kacheln(inlay = false)
    for (n = [1:9]) translate([((n-1)%3 - 1)*TP, -(floor((n-1)/3) - 1)*TP, TILE_T]) rotate([0, 180, 0])
        if (inlay) tile_inlay(n); else tile_body(n);

if (part == "basis")         basis_body();
if (part == "rahmen")        rahmen_body();
if (part == "rahmen_inlay")  rahmen_inlay();
if (part == "kacheln")       kacheln(false);
if (part == "kacheln_inlay") kacheln(true);
if (part == "kachel")        tile_body(TILE_NO);
if (part == "kachel_inlay")  tile_inlay(TILE_NO);
if (part == "figur")         coin();
if (part == "huelle")        huelle();
if (part == "qr_platte")     qr_platte();
if (part == "qr_platte_qr")  qr_platte_qr();
// standing on one open end, as printed
if (part == "huelle_druck")  translate([0, 0, SL_L/2]) rotate([-90, 0, 0]) translate([0, 0, -SL_OH/2]) huelle();
if (part == "huelle_stuetze")         huelle_stuetze();
if (part == "huelle_stuetze_kontakt") huelle_stuetze_kontakt();
if (part == "huelle_mit_stuetze") {
    color("darkslategray") translate([0, 0, SL_L/2]) rotate([-90, 0, 0]) translate([0, 0, -SL_OH/2]) huelle();
    color("burlywood") huelle_stuetze();
    color("orangered") huelle_stuetze_kontakt();
}
// board in the sleeve, coin under the rubber band
if (part == "verpackt") {
    color("darkslategray") huelle();
    translate([0, 0, SL_PLATE]) {
        color("saddlebrown") basis_body();
        translate([0, 0, FLOOR]) color("peru") rahmen_body();
        for (n = [1:9]) translate([cell(n)[0], cell(n)[1], FLOOR]) color("burlywood") tile_body(n);
    }
    // QR plate turned visible side up, coin pressed through its hole
    translate([-QP_HX, 12, SL_OH + QP_T]) rotate([0, 180, 0]) { color("white") qr_platte(); color("black") qr_platte_qr(); }
    translate([0, 12, SL_OH]) color("red") coin();
    color("gold") {                  // rubber band around the length, through the notches
        translate([-1.5, -SL_L/2 + 0, SL_OH + COIN_H - SLOT_D]) cube([3, SL_L, 0.8]);
        translate([-1.5, -SL_L/2 - 0.8, 0]) cube([3, 0.8, SL_OH + COIN_H]);
        translate([-1.5, SL_L/2, 0]) cube([3, 0.8, SL_OH + COIN_H]);
        translate([-1.5, -SL_L/2, -0.8]) cube([3, SL_L, 0.8]);
    }
}
if (part == "baugruppe") {
    color("saddlebrown") basis_body();
    translate([0, 0, FLOOR]) { color("peru") rahmen_body(); color("ivory") rahmen_inlay(); }
    for (n = [1:9]) if (n != 7) translate([cell(n)[0], cell(n)[1], FLOOR]) {
        color("burlywood") tile_body(n);
        color("black") tile_inlay(n);
    }
    translate([cell(1)[0], cell(1)[1], FLOOR + TILE_T]) color("red") coin();
}
// ring turned over (about the vertical axis), as the audience sees it
if (part == "rueckseite") translate([0, 0, WALL_H]) rotate([0, 180, 0]) {
    color("peru") rahmen_body(); color("ivory") rahmen_inlay();
}
