// QR-Platte des Bretts der Wunder ohne QR-Code (11.11.2026):
// gleiche Platte 44,1 x 25 x 2,4 mit Pressloch für die Münze, nur die
// QR-Aussparung fällt weg (qp_qr_2d leer). Für die Box-Sets.
include <../../brett_der_wunder/brett_der_wunder.scad>
part = "none";
module qp_qr_2d() {}
qr_platte();
