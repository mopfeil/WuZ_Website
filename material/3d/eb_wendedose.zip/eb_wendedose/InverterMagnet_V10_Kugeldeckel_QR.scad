// ===================================================================
//  WuZ-Experiment: Inverter-Magnet ("Tractor Magnet") – 3D-Druck-Rahmen
//  NACHTRAG 02.11.2026: Stützeinlage für die Kuhlen (part "kuhle_stuetze").
//  Beide Kuhlen liegen beim Druck unten auf dem Bett; die Scheibe füllt die
//  Kuhle genau (Ø KB_D_MAJ + 2*KB_REC_CLR, Höhe KB_REC_H = 2 Schichten) und
//  wird in Stützfilament (Bambu Support for PLA) gedruckt. Gleiche
//  Koordinaten wie Unterteil und Deckel in Druckausrichtung, d. h. als
//  Teil desselben Objekts mittig am Bett. Dose sonst unverändert.
//  VARIANTE 10 (28.10.2026) = V9, aber der QR-Code sitzt nicht mehr auf der
//  Dose, sondern oben auf dem Kugeldeckel. Der Deckel ist dafür größer
//  (CAP_D, aus der Codegröße abgeleitet), reicht bis KB_CAP_GAP über die
//  Dosenfläche und ist oben rund abgekantet. Code: weiße Scheibe als Einlage
//  (helle Module + Ruhezone), die dunklen Module bleiben Grundfarbe.
//  Damit braucht kein Druck Stützfilament UND Weiß zugleich:
//    - Dose (Unterteil, Deckel): Grundfarbe + Stützfilament für die Kuhlen,
//    - Kugeldeckel + qr_kugeldeckel: Grundfarbe + Weiß (aufrecht gedruckt,
//      Code oben, keine Stützen),
//    - Kugelbox: einfarbig, unverändert.
//  VARIANTE 9 (26.10.2026) = V8 mit QR-Code auf BEIDEN Außenflächen
//  (HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/I, Anleitung Wendedose), damit die
//  Dose nach dem Wenden gleich aussieht. Einlage QR_DEPTH tief, zweite Farbe.
//  Die Fläche zwischen Kuhle (Ø13.3) und Außenfase lässt nur 14.5 mm zu
//  (Modul 0.58), der Code sitzt außermittig neben der Kuhle. Auf der
//  Bodenseite gespiegelt (liest sich von unten). Geometrie sonst wie V8.
//  Druck: Unterteil + QR_unterteil als EIN Objekt, Deckel + QR_deckel als
//  EIN Objekt (gleiche Koordinaten), QR-Teile -> dunkles Filament. Für
//  Bambu "Teil hinzufügen" die *_teil.stl nehmen.
//  VARIANTE 8 (13.10.2026) = V7 mit den 6-mm-Magneten aus V3:
//  Mitte 1 × Ø20 × 6, Ring 6 × Ø6 × 6 auf Teilkreis R 15.5. Alle Maße
//  (Gewinde, Außen-Ø, Fuge) leiten sich wie in V7 daraus ab.
//  VARIANTE 7 (12.10.2026) = V6 kompakter: Wand Ringtasche–Gewindegrund nur
//  noch RING_WALL (dünn nur an 8 kurzen Stellen), Gewinde- und Außen-Ø werden
//  daraus berechnet. Magnetlage (R_RING) unverändert.
//  VARIANTE 6 (12.10.2026) = V5 mit Fuge genau in der Mitte der Außenhöhe.
//  V5-Text: Magnete wie V2 (Mitte Ø20 × 5, Ring 8 × Ø5 × 5),
//  aber als WENDEDOSE mit zwei verschiedenen Abständen:
//    - Unterteil unten (Boden auf dem Tisch): Magnete 1.0 mm über dem Tisch,
//      Deckelseite oben 2.0 mm über den Magneten.
//    - Deckel unten: Magnete 2.0 mm über dem Tisch, Bodenseite oben 1.0 mm.
//  Beide Außenseiten haben mittig eine Kuhle für die Kugelbox (wie V3, ohne
//  Figur). Der Zapfen der Box füllt die Kuhle genau aus; der Fachboden liegt
//  bündig mit der Außenfläche. Die Kugeln liegen also auf der Bodenseite 1.0 mm,
//  auf der Deckelseite 2.0 mm über den Magneten: einmal klappt es, einmal nicht.
//
//  Fuge in der Mitte (neu in V6): Außen treffen sich Deckel und Unterteil genau
//  auf halber Höhe (Z_MID). Innen greift ein schmaler Gewindekragen des Deckels
//  in eine Ringnut des Unterteils, so dass das Gewinde wie in V5 3.5 mm tief
//  trägt (gleiche Zahl an Windungen). Dafür ist der Außen-Ø auf 50 mm gewachsen.
//
//  Magnete (V8): 1 × Scheibe Ø20 × 6 mm (Mitte), 6 × Zylinder Ø6 × 6 mm (Ring),
//           NdFeB, axial magnetisiert. Alle Maße in mm.
//
//  Druck: Unterteil mit der Bodenseite aufs Bett, Deckel mit der Platte aufs
//  Bett. Die 0.4-mm-Kuhlen liegen dabei unten; die Schicht darüber wird als
//  Brücke (Ø13.3) gedruckt, das ist unkritisch.
//  Bedienung: unten "part" wählen, F6 (Rendern), dann F7 (STL-Export).
// ===================================================================

/* [Auswahl] */
part = "alle_druckplatte"; // [baugruppe, schnitt, unterteil, deckel, kugelbox, kugeldeckel, qr_kugeldeckel, kuhle_stuetze, alle_druckplatte]

/* [Magnete] */
C_D = 20.0;            // Mittelmagnet-Durchmesser
C_H = 6.0;             // Mittelmagnet-Höhe
C_POCKET_D = 20.3;     // Taschen-Ø Mitte
R_D = 6.0;             // Ringmagnet-Durchmesser
R_H = 6.0;             // Ringmagnet-Höhe
R_POCKET_D = 6.2;      // Taschen-Ø Ring
R_RING = 15.5;         // Teilkreisradius der Ringmagnete
N_RING = 6;            // Anzahl Ringmagnete
POCKET_EXTRA = 0.1;    // Taschen 0.1 mm tiefer als Magnet (Deckel drückt nach)

/* [Abstände Magnet – Außenfläche] */
BASE_FLOOR = 1.0;      // Bodenseite: Magnet – Tisch / Magnet – Kugel
LID_PLATE  = 2.0;      // Deckelseite: Magnet – Tisch / Magnet – Kugel

/* [Gehäuse] */
BASE_H  = max(C_H, R_H) + POCKET_EXTRA + BASE_FLOOR; // Höhe Unterteil (= 7.1)
SLEEVE_WALL = 1.8;     // Außenwand des Unterteils um die Ringnut (Rändel nimmt 0.6 weg)
SEAM    = 0.2;         // Luft in der Außenfuge (je zur Hälfte über/unter Z_MID)
COLLAR_WALL = 1.2;     // Wandstärke des Gewindekragens am Deckel (außen am Gewindegrund)
GROOVE_CLR  = 0.3;     // radiales Spiel Kragen/Ringnut
CHAMFER = 0.8;         // Außenfasen (Deckel oben, Unterteil unten)

/* [Gewinde] */
THREAD_L = 3.5;        // tragende Gewindelänge (= Kragenunterkante unter der Plattenunterseite)
P     = 2.5;           // Steigung
RING_WALL = 0.8;       // engste Wand Ringmagnettasche – Gewindegrund (2 Perimeter)
H_TH  = 1.2;           // Gewindetiefe (radial)
CLR   = 0.35;          // radiales Spiel Innengewinde (bei zu strammem Gewinde: 0.4–0.5)

/* [Kugelfach] */
KUGELFACH  = true;
BALL_D     = 3.0;      // Kugel-Ø
KB_WELL_D  = 8.0;      // Innen-Ø Fach
KB_WELL_H  = 3.4;      // Fachtiefe (Kugel + 0.4 Luft)
KB_REC_H   = 0.4;      // Tiefe der Kuhlen = Zapfenhöhe = Boden der Box
KB_REC_CLR = 0.15;     // radiales Spiel Zapfen/Kuhle
KB_SLOT_W  = 4.0;      // Breite des seitlichen Schlitzes
KB_D_MAJ   = 13.0;     // Außen-Ø Gewinde der Box
KB_H_TH    = 0.6;      // Gewindetiefe
KB_P       = 1.5;      // Steigung
KB_CLR     = 0.3;      // radiales Spiel
KB_CAP_PLATE = 1.4;    // Dicke Kugeldeckelplatte (Brücke + 3 Schichten unter der QR-Einlage)
KB_CAP_GAP   = 0.3;    // Luft Deckelunterkante – Dosenfläche
CAP_ROUND    = 2.0;    // Rundung der oberen Außenkante
CAP_FOOT     = 0.4;    // 45°-Fase unten (gegen Elefantenfuß)

/* [QR-Code oben auf dem Kugeldeckel] */
QR_ON    = true;
QR_MOD   = 0.72;       // Modulgröße (25 Module -> 18 mm)
QR_DEPTH = 0.6;        // Einlagetiefe (3 Schichten à 0.2)
QR_QUIET = 1.3;        // Ruhezone an den Code-Ecken (weißer Rand bis zur Scheibenkante)

// HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/I, Version 2-M (segno), alphanumerisch
// (Großbuchstaben, HTTP, damit 38 Zeichen passen). Zeile 0 = oben, "1" = dunkel.
QR = [
    "1111111011001101001111111",
    "1000001000001000101000001",
    "1011101011100101001011101",
    "1011101000011011001011101",
    "1011101000110101101011101",
    "1000001011101101101000001",
    "1111111010101010101111111",
    "0000000000100000000000000",
    "1010001101101011000100101",
    "0010000001010101010011001",
    "1001111000111001100110101",
    "1101010101001101110001101",
    "0000101010111111111010010",
    "0010000000101100010100101",
    "1111111011011011001000110",
    "0011010001100001101111110",
    "1100111001001110111110011",
    "0000000011011010100011111",
    "1111111010000010101010111",
    "1000001000111111100011011",
    "1011101000101101111110011",
    "1011101001110010101100110",
    "1011101010101101001100011",
    "1000001001001001011011001",
    "1111111010110011101011111"
];

/* [Rändel] */
KNURL_N = 40;
KNURL_R = 1.2;

/* [Auflösung] */
TH_SEG = 128;
TH_DZ  = 0.125;
$fn = 96;

// ---------- abgeleitete Werte ----------
RING_DEPTH   = R_H + POCKET_EXTRA;
CENTER_DEPTH = C_H + POCKET_EXTRA;
Z_MID        = (LID_PLATE - BASE_H)/2;    // halbe Außenhöhe (= -2.55)
R_MIN        = R_RING + R_POCKET_D/2 + RING_WALL;  // Gewindegrund (= 19.4)
D_MAJ        = 2*(R_MIN + H_TH);           // Außen-Ø Außengewinde (= 41.2)
R_COLLAR     = R_MIN + CLR + H_TH + COLLAR_WALL;  // Außenradius Gewindekragen (= 22.15)
R_SLEEVE     = R_COLLAR + GROOVE_CLR;      // Innenradius der Außenwand des Unterteils
GRIP_D       = 2*(R_SLEEVE + SLEEVE_WALL);  // Außen-Ø Deckel und Unterteil (= 48.5)
echo(D_MAJ = D_MAJ, GRIP_D = GRIP_D);
Z_GROOVE     = -THREAD_L - 0.3;            // Nutgrund (0.3 Luft unter dem Kragen)
TH_Z0        = Z_GROOVE - 0.3;             // Gewindebeginn (0.3 im Nutgrund versenkt)
KB_H         = KB_WELL_H;                  // Höhe Kugelbox über der Auflagefläche
KB_SKIRT     = KB_H - KB_CAP_GAP;
KB_R_MIN     = KB_D_MAJ/2 - KB_H_TH;
EPS = 0.01;

assert(BASE_FLOOR - KB_REC_H >= 0.4, "Boden unter der Kuhle zu dünn");
assert(GRIP_D/2 - R_SLEEVE - KNURL_R/2 >= 1.2, "Außenwand des Unterteils zu dünn");
assert(Z_GROOVE > -BASE_H + 1.5, "Nutgrund zu nah am Boden");
QR_S  = len(QR)*QR_MOD;                         // Kantenlänge
QR_R  = QR_S/sqrt(2) + QR_QUIET;                // Radius der weißen Scheibe
CAP_D = 2*(QR_R + 0.4 + CAP_ROUND);             // Außen-Ø Kugeldeckel (flache Oberseite trägt die Scheibe)
echo(CAP_D = CAP_D, QR_S = QR_S);
assert(KB_CAP_PLATE - QR_DEPTH >= 0.6, "Platte unter der QR-Einlage zu dünn");
assert(CAP_D < GRIP_D - 2*CHAMFER, "Kugeldeckel größer als die Dosenfläche");

// ===================================================================
//  Gewinde als Polyeder: r(θ,z) = r_min + H·Profil(u),  u = z/P − θ/360
//  Trapezprofil ~60°, rechtsgängig.
//  cone_top  : 45°-Anlauffase am oberen Ende (Außengewinde), -1 = aus
//  lead_in   : [z_ref, r_ref] 45°-Aufweitung nach unten (Innengewinde), [] = aus
// ===================================================================
function clamp01(x) = min(1, max(0, x));
function tprofile(u) = clamp01((abs(u - 0.5)*2 - 0.2) / 0.6);
function frac(x) = x - floor(x);

function th_r(a, z, rmin, H, z0, z1, cone_top, lead_in, p = P) =
    let(u  = frac((z - z0)/p - a/360),
        r0 = rmin + H*tprofile(u),
        r1 = cone_top > 0 ? max(min(r0, cone_top + (z1 - z)), rmin) : r0,
        r2 = len(lead_in) == 2 ? max(r1, lead_in[1] - (z - lead_in[0])) : r1)
    r2;

module thread_body(rmin, H, z0, z1, cone_top = -1, lead_in = [], p = P) {
    nz = round((z1 - z0)/TH_DZ) + 1;
    na = TH_SEG;
    pts = concat(
        [for (j = [0:nz-1]) for (i = [0:na-1])
            let(z = z0 + (z1 - z0)*j/(nz-1), a = 360*i/na,
                r = th_r(a, z, rmin, H, z0, z1, cone_top, lead_in, p))
            [r*cos(a), r*sin(a), z]],
        [[0, 0, z0], [0, 0, z1]]);
    cb = nz*na; ct = cb + 1;
    function id(j, i) = j*na + (i % na);
    faces = concat(
        [for (j = [0:nz-2]) for (i = [0:na-1]) each [
            [id(j,i), id(j+1,i+1), id(j,i+1)],
            [id(j,i), id(j+1,i),   id(j+1,i+1)]]],
        [for (i = [0:na-1]) [cb, id(0,i), id(0,i+1)]],
        [for (i = [0:na-1]) [ct, id(nz-1,i+1), id(nz-1,i)]]);
    polyhedron(points = pts, faces = faces, convexity = 10);
}

module knurl(z0, h, d = GRIP_D, n = KNURL_N, r = KNURL_R) {
    for (k = [0:n-1])
        rotate([0, 0, 360*k/n])
            translate([d/2 + r/2, 0, z0 - 1])
                cylinder(h = h + 2, r = r, $fn = 24);
}

module pockets() {
    translate([0, 0, -CENTER_DEPTH]) cylinder(h = CENTER_DEPTH + 1, d = C_POCKET_D);
    for (k = [0:N_RING-1])
        rotate([0, 0, 360*k/N_RING])
            translate([R_RING, 0, -RING_DEPTH]) cylinder(h = RING_DEPTH + 1, d = R_POCKET_D, $fn = 48);
}


module kuhle(z_face, up) {   // Kuhle für den Kugelbox-Zapfen in einer Außenfläche
    translate([0, 0, up ? z_face - KB_REC_H : z_face - 1])
        cylinder(h = KB_REC_H + 1, d = KB_D_MAJ + 2*KB_REC_CLR);
}

// ---------- QR-Code (2D, Leserichtung von oben, mittig) ----------
module qr_dark_2d() {
    n = len(QR);
    for (r = [0:n-1]) for (c = [0:n-1])
        if (QR[r][c] == "1")
            translate([(c - n/2)*QR_MOD, (n/2 - 1 - r)*QR_MOD]) square(QR_MOD + 0.002);
}
// Weiße Einlage: Scheibe minus dunkle Module (die bleiben Grundfarbe)
module qr_white_2d() difference() { circle(r = QR_R, $fn = 128); qr_dark_2d(); }
module qr_kugeldeckel(extra = 0)
    translate([0, 0, KB_CAP_PLATE - QR_DEPTH]) linear_extrude(QR_DEPTH + extra) qr_white_2d();

// ---------- Unterteil (Oberkante Gewinde = z 0) ----------
module unterteil() {
    zb = -BASE_H; h = Z_MID - SEAM/2 - zb;
    difference() {
        union() {
            // Außenwand bis zur Fuge, Rändel, 45°-Fase unten
            intersection() {
                difference() {
                    translate([0, 0, zb]) cylinder(h = h, d = GRIP_D);
                    knurl(zb, h);
                }
                translate([0, 0, zb]) cylinder(h = h, r1 = GRIP_D/2 - CHAMFER, r2 = GRIP_D/2 - CHAMFER + h);
            }
            // Außengewinde mit Anlauffase
            thread_body(R_MIN, H_TH, TH_Z0, 0, cone_top = D_MAJ/2 - CHAMFER);
        }
        // Ringnut für den Gewindekragen des Deckels (das Gewinde selbst bleibt stehen)
        difference() {
            translate([0, 0, Z_GROOVE]) cylinder(h = 10, r = R_SLEEVE);
            thread_body(R_MIN, H_TH, TH_Z0, 0, cone_top = D_MAJ/2 - CHAMFER);
            translate([0, 0, Z_GROOVE - 1]) cylinder(h = 12, r = R_MIN + EPS);
        }
        pockets();
        if (KUGELFACH) kuhle(zb, false);
    }
}

// ---------- Schraubdeckel (Plattenunterseite = z 0) ----------
module deckel() {
    z0 = Z_MID + SEAM/2; h = LID_PLATE - z0;
    difference() {
        union() {
            // Außenteil von der Fuge bis oben, Rändel, 45°-Fase oben
            intersection() {
                difference() {
                    translate([0, 0, z0]) cylinder(h = h, d = GRIP_D);
                    knurl(z0, h);
                }
                translate([0, 0, z0]) cylinder(h = h, r1 = GRIP_D/2 - CHAMFER + h, r2 = GRIP_D/2 - CHAMFER);
            }
            // Gewindekragen, greift in die Ringnut des Unterteils
            translate([0, 0, -THREAD_L]) cylinder(h = THREAD_L + z0 + EPS, r = R_COLLAR);
        }
        // Innengewinde: gleiche Phase wie Unterteil, radial +CLR, mit Einführfase
        thread_body(R_MIN + CLR, H_TH, TH_Z0, 0,
                    lead_in = [-THREAD_L, D_MAJ/2 + CLR + 0.6]);
        if (KUGELFACH) kuhle(LID_PLATE, true);
    }
}

// ---------- Kugelbox (z 0 = Auflagefläche = Fachboden, Zapfen darunter) ----------
module kugelbox() {
    difference() {
        union() {
            thread_body(KB_R_MIN, KB_H_TH, 0, KB_H, cone_top = KB_D_MAJ/2 - 0.4, p = KB_P);
            translate([0, 0, -KB_REC_H]) cylinder(h = KB_REC_H + EPS, d = KB_D_MAJ);
        }
        // Fach, Boden bündig mit der Auflagefläche
        cylinder(h = KB_H + 1, d = KB_WELL_D, $fn = 48);
        // seitlicher Schlitz: Kugeln rollen ohne Stufe auf die Dose
        translate([0, -KB_SLOT_W/2, 0]) cube([KB_D_MAJ, KB_SLOT_W, KB_H + 1]);
    }
}

// ---------- Kugeldeckel (Plattenunterseite = z 0) ----------
// Flache Scheibe CAP_D, Unterkante KB_CAP_GAP über der Dosenfläche, oben mit
// CAP_ROUND gerundet, unten kleine Fase; Griffrillen nur außen.
module cap_outline() {
    R = CAP_D/2; zb = -KB_SKIRT; zt = KB_CAP_PLATE;
    hull() {
        translate([0, zb]) square([R - CAP_FOOT, EPS]);
        translate([0, zb + CAP_FOOT]) square([R, EPS]);
        translate([R - CAP_ROUND, zt - CAP_ROUND]) circle(r = CAP_ROUND, $fn = 48);
        translate([0, zt - EPS]) square([R - CAP_ROUND, EPS]);
    }
}
module kugeldeckel() {
    h = KB_SKIRT + KB_CAP_PLATE;
    difference() {
        rotate_extrude($fn = 160) cap_outline();
        knurl(-KB_SKIRT, h, d = CAP_D, n = 48, r = 0.6);
        thread_body(KB_R_MIN + KB_CLR, KB_H_TH, -KB_H, 0,
                    lead_in = [-KB_SKIRT, KB_D_MAJ/2 + KB_CLR + 0.4], p = KB_P);
        if (QR_ON) qr_kugeldeckel(1);
    }
}

// ---------- Ansicht ----------
// Halbschnitt-Hilfe: entfernt die vordere Hälfte (y < 0)
module half(cut) {
    if (cut) difference() { children(); translate([-100, -200, -100]) cube(200); }
    else children();
}

module box_mit_kugeln(cut, a) {
    color("Wheat") half(cut) kugelbox();
    for (x = [-BALL_D/2 - 0.1, BALL_D/2 + 0.1])
        color("Silver") translate([x, 0, BALL_D/2]) sphere(d = BALL_D, $fn = 24);
    color("DarkSeaGreen", a) half(cut) translate([0, 0, KB_H]) kugeldeckel();
    if (QR_ON) color("White") half(cut) translate([0, 0, KB_H]) qr_kugeldeckel();
}

// Lage "Unterteil unten": Box auf der Deckelseite (2.0 mm, klappt nicht)
module baugruppe(cut = false) {
    a = cut ? 1 : 0.85;
    color("Tan") half(cut) unterteil();
    color("Firebrick") half(cut) translate([0, 0, -C_H]) cylinder(h = C_H, d = C_D);
    for (k = [0:N_RING-1])
        color("RoyalBlue") half(cut) rotate([0, 0, 360*k/N_RING]) translate([R_RING, 0, -R_H]) cylinder(h = R_H, d = R_D, $fn = 48);
    color("DarkSeaGreen", a) half(cut) deckel();
    if (KUGELFACH) translate([0, 0, LID_PLATE]) box_mit_kugeln(cut, a);
}

// Stützeinlage: füllt die Kuhle in Druckausrichtung (Kuhle unten, z 0..KB_REC_H)
module kuhle_stuetze() cylinder(h = KB_REC_H, d = KB_D_MAJ + 2*KB_REC_CLR);

// ---------- Ausgabe ----------
// Kugeldeckel aufrecht (Unterkante aufs Bett, Code oben, liest sich von oben)
if (part == "unterteil") translate([0, 0, BASE_H]) unterteil();
else if (part == "deckel") rotate([180, 0, 0]) translate([0, 0, -LID_PLATE]) deckel(); // Platte aufs Bett
else if (part == "kuhle_stuetze") kuhle_stuetze();
else if (part == "kugelbox") translate([0, 0, KB_REC_H]) kugelbox();
else if (part == "kugeldeckel") translate([0, 0, KB_SKIRT]) kugeldeckel();
else if (part == "qr_kugeldeckel") translate([0, 0, KB_SKIRT]) qr_kugeldeckel();
else if (part == "baugruppe") baugruppe();
else if (part == "schnitt") baugruppe(cut = true);
else if (part == "alle_druckplatte") {
    translate([0, 0, BASE_H]) unterteil();
    translate([GRIP_D + 5, 0, 0]) rotate([180, 0, 0]) translate([0, 0, -LID_PLATE]) deckel();
    if (KUGELFACH) {
        translate([GRIP_D/2 + 2.5, -GRIP_D/2 - 2, KB_REC_H]) kugelbox();
        translate([GRIP_D/2 + 2.5 + KB_D_MAJ/2 + CAP_D/2 + 4, -GRIP_D/2 - 2, KB_SKIRT]) {
            kugeldeckel(); if (QR_ON) color("White") qr_kugeldeckel(); }
    }
}
