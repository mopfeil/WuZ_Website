// =====================================================================
//  Charpentier-Deckel (flat3, v5): Druckstütze für die Stapelmulde (11.11.2026)
// ---------------------------------------------------------------------
//  Der Deckel wird mit der Oberseite aufs Bett gedruckt. Die Stapelmulde
//  (37,6 x 23,6 x 1,6) liegt dabei unten offen, die 0,8 dünne Deckelplatte
//  darüber ist eine Brücke über 23,6 mm. Bisher hat Markus dafür die
//  Slicer-Stützen eingeschaltet. Hier ist die Stütze ein eigenes Teil nach
//  dem Muster der Hindufaden-Stütze v3 (10.11.2026):
//    - kern:    PLA, auf dem Bett, 0,8 Luft zu den Muldenwänden, 1,2 hoch,
//               oben Rillengitter (1,2 breit, 0,4 tief, Teilung 4) zum Verzahnen
//    - kontakt: Supportfilament, nur 0,4 (2 Schichten) unter der Deckelplatte
//               plus Rillenfüllung
//    - mod:     Modifier 100 % Füllung für die Deckelplatte über der Stütze
//               (Bambu erkennt eine Fläche auf Supportfilament nicht als Boden)
//  Kein Supportfilament direkt auf dem Bett. Gleiche Koordinaten wie
//  ../../charpentier/flat3_lid.stl (part "lid"). Nach dem Druck den Kern
//  samt Kontaktschicht aus der Mulde drücken.
//  charpentier_lib.scad = charpentier_flat3_boxes.scad bis vor die
//  Teileauswahl (erzeugt build.sh).
//    openscad -D 'teil="kern"'    -o charpentier_deckel_stuetze_kern.stl    charpentier_deckel_stuetze.scad
//    openscad -D 'teil="kontakt"' -o charpentier_deckel_stuetze_kontakt.stl charpentier_deckel_stuetze.scad
//    openscad -D 'teil="mod"'     -o charpentier_deckel_stuetze_mod.stl     charpentier_deckel_stuetze.scad
// =====================================================================
include <charpentier_lib.scad>

teil = "vorschau"; // [kern, kontakt, mod, vorschau]

ST_GAP   = 0.8;   // Luft Kern <-> Muldenwand
IF_T     = 0.4;   // Supportfilament unter der Deckelplatte (2 Schichten à 0.2)
ANCH_W   = 1.2;   // Rillenbreite
ANCH_D   = 0.4;   // Rillentiefe
ANCH_P   = 4.0;   // Rillenteilung
ANCH_RIM = 1.2;   // rillenfreier Rand am Kern

RX = ox + 2*stack_clr;  RY = oy + 2*stack_clr;  RR = r_out + stack_clr;   // Mulde
CORE_H = stack_recess - IF_T;                                              // 1.2
assert(CORE_H - ANCH_D >= 0.6, "Kern zu dünn");

module core2d() rrect(RX - 2*ST_GAP, RY - 2*ST_GAP, max(RR - ST_GAP, 0.3));
module grooves2d() intersection() {
    offset(delta = -ANCH_RIM) core2d();
    union() {
        for (i = [-10:10]) translate([i*ANCH_P - ANCH_W/2, -RY]) square([ANCH_W, 2*RY]);
        for (i = [-10:10]) translate([-RX, i*ANCH_P - ANCH_W/2]) square([2*RX, ANCH_W]);
    }
}

module kern() difference() {
    linear_extrude(CORE_H) core2d();
    translate([0, 0, CORE_H - ANCH_D]) linear_extrude(ANCH_D + 1) grooves2d();
}
module kontakt() {
    translate([0, 0, CORE_H - ANCH_D]) linear_extrude(ANCH_D) grooves2d();
    translate([0, 0, CORE_H]) linear_extrude(IF_T) core2d();
}
module mod() translate([0, 0, stack_recess]) linear_extrude(lid_t) rrect(RX, RY, RR);

if (teil == "kern") kern();
else if (teil == "kontakt") kontakt();
else if (teil == "mod") mod();
else if (teil == "vorschau") {
    color("Orange", 0.4) lid_print();
    color("SteelBlue") kern();
    color("White") kontakt();
}
