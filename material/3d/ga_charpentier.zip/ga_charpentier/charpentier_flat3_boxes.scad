// =====================================================================
//  Charpentier illusion – three identical stackable boxes
// ---------------------------------------------------------------------
//  * All boxes identical; the box holds three 11 x 19 x 3.7 mm weights
//    lying SIDE BY SIDE (long edges touching, 33 x 19 footprint). Glue the weights into one box, the
//    others stay empty – from outside they look the same.
//  * Cap lid that snaps shut from the outside: the lid skirt slips over
//    the box, two slotted tabs with barbs click into grooves in the
//    outer box wall.
//    permanent = true  -> lid cannot be pulled off again (glue first!)
//    permanent = false -> sloped barbs, lid can be pulled off with force.
//    The box is the same for both lid versions.
//  * Stackable: the box bottom sticks out stack_h below the lid skirt
//    and drops into an equally deep recess in the lid below; the skirt
//    rim then sits flat on the lid underneath. Chamfers on both centre
//    the boxes.
//
//  v2 (2026-10-09): longer skirt = longer, softer snap tabs; groove moved
//  down next to the floor, where the box wall cannot flex away; deeper
//  groove for a clear click; stack engagement 0.8 -> 2.5 mm.
//
//  v3 (2026-10-12): flat box – weights side by side instead of stacked;
//  thinner walls, floor, skirt and lid plate so the empty boxes weigh less
//  and the weight difference stands out. The tabs get shorter (low box),
//  so barb/groove are reduced to keep the bending strain safe for PLA.
//
//  v4 (2026-10-13): three weights side by side; more clearance sideways
//  (0.8 per side) and above (0.8), because the weights vary in size and
//  are glued in anyway.
//
//  v5 (2026-10-26): 0.5 mm more free height above the weights (Markus:
//  "sitzt sehr knapp"), height_clr 0.8 -> 1.3; box and lid skirt grow by
//  0.5. Optional QR code (HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/C, trick
//  explanation) as an inlay in the underside of ONE box: print one box
//  as flat3_body_qr.stl + flat3_qr.stl (second colour, one object with
//  two parts), the other two as flat3_body.stl. The QR box goes at the
//  bottom of the stack, so the code stays hidden on the table.
//
//  Print: boxes upright, lids top-down (as laid out). No supports.
//  The recess in the lid is a short bridge (≈15 mm) – fine on any
//  normal printer.
//
//  Export single parts:
//    openscad -D 'part="body"' -o flat3_body.stl charpentier_flat3_boxes.scad
//    openscad -D 'part="lid"'  -o flat3_lid.stl  charpentier_flat3_boxes.scad
//    openscad -D 'part="body_qr"' -o flat3_body_qr.stl charpentier_flat3_boxes.scad
//    openscad -D 'part="qr"'      -o flat3_qr.stl      charpentier_flat3_boxes.scad
// =====================================================================

/* [View] */
part  = "all";     // [all, body, body_qr, qr, lid, assembly, section]
count = 3;         // number of boxes in the "all" layout

/* [Weights] */
weight    = [11, 19, 3.7];  // one weight: x, y, thickness
n_side    = 3;              // side by side along x (long edges touching)
n_weights = 1;              // stacked
weight_clr = 0.8;           // clearance around the weights (each side)   v3: 0.3
height_clr = 1.3;           // free height above the weights              v4: 0.8, v3: 0.3

/* [Box] */
wall    = 1.3;     // side wall (groove is cut into it)        v2: 1.6
floor_t = 0.8;     // bottom                                    v2: 1.0
r_out   = 1.5;     // outer corner radius of the box
top_chamfer = 0.5; // lead-in for the lid barbs
bot_chamfer = 0.5; // bottom edge: centres the box in the recess, hides elephant foot

/* [Lid] */
skirt_t = 1.0;     // lid skirt wall                            v2: 1.2
lid_t   = 0.8;     // lid plate (stack recess comes on top)     v2: 1.0
fit     = 0.15;    // radial gap box <-> skirt

/* [Snap] */
permanent = true;  // true: one-way snap, false: removable
tab_w   = 10;      // width of the snap tabs (long sides)
slit    = 0.6;     // slits beside the tabs
barb    = 0.45;    // barb height (interference = barb - fit)   v2: 0.6
groove_d = 0.5;    // groove depth in the box wall              v2: 0.6

/* [Stacking] */
stack_h   = 1.5;   // box bottom below the skirt rim = recess depth in the lid   v2: 2.5
stack_clr = 0.2;   // radial gap box bottom <-> recess

/* [QR code in the underside] */
QR_MOD   = 0.72;   // module size (25 modules -> 18.0 mm)
QR_DEPTH = 0.6;    // inlay depth (3 layers of 0.2)

// HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/C, version 2-M (segno), alphanumeric
// (upper case, HTTP so 38 characters fit). Row 0 = top, "1" = dark module.
QR = [
    "1111111011000011101111111",
    "1000001011011010101000001",
    "1011101001010110001011101",
    "1011101010000010001011101",
    "1011101001110000001011101",
    "1000001001010001001000001",
    "1111111010101010101111111",
    "0000000011001010000000000",
    "1011011101010000001001011",
    "1101110110110100011010000",
    "0010011110101100001011000",
    "0100100100000001010101001",
    "0001101001001001001100100",
    "0011010010011110000110111",
    "0100101011110000010011101",
    "1000100111010000100110111",
    "0010011101010011111111110",
    "0000000011011110100011011",
    "1111111010110100101010001",
    "1000001010001101100011001",
    "1011101000110110111111000",
    "1011101010011011100101111",
    "1011101011100000100001110",
    "1000001001101101111111101",
    "1111111010100101011101001"
];

$fn = 48;
eps = 0.01;

// ---------------------------------------------------------------------
// derived dimensions
// ---------------------------------------------------------------------
ix = n_side * weight[0] + 2*weight_clr;
iy = weight[1] + 2*weight_clr;
iz = n_weights * weight[2] + height_clr;
ox = ix + 2*wall;                 // box outside
oy = iy + 2*wall;
Hb = stack_h + floor_t + iz;      // box height (floor raised by stack_h)
sx = ox + 2*fit;                  // skirt inside
sy = oy + 2*fit;
lx = sx + 2*skirt_t;              // lid outside
ly = sy + 2*skirt_t;
stack_recess = stack_h + 0.1;     // a little deeper: the skirt rim carries the stack
Tl = lid_t + stack_recess;        // lid plate thickness
H  = Hb + Tl;                     // closed height
zs = stack_h;                     // skirt rim z (lid closed)
skirt_h = Hb - zs;                // = snap tab length

// barb profile along the tab (v measured up from the skirt rim)
v0 = 0.2;                         // bevel at the rim
v1 = v0 + 1.2;                    // end of the entry ramp
v2 = v1 + 0.3;                    // top of the barb
g0 = zs + v0 - 0.2;               // groove bottom
g1 = zs + v2 + 0.1;               // groove top (retaining edge)

assert(barb - fit <= groove_d, "groove too shallow for the barb");
assert(wall - groove_d >= 0.8, "wall too thin behind the groove");
assert(g1 < Hb - 2, "box too low for the snap");
// bending strain of a snap tab (cantilever): 1.5 * t * deflection / L^2
tab_strain = 1.5 * skirt_t * (barb - fit) / (skirt_h * skirt_h);
assert(tab_strain <= 0.025, "snap tab strain too high for PLA");

echo(str("Box: ", ox, " x ", oy, " x ", Hb, " mm | closed with lid: ",
         lx, " x ", ly, " x ", H, " mm | inside ", ix, " x ", iy, " x ", iz,
         " | stack pitch ", H - stack_recess, " mm | tab length ", skirt_h,
         " | tab strain ", round(tab_strain*1000)/10, " %"));

// ---------------------------------------------------------------------
module rrect(x, y, r) offset(r = r) square([x - 2*r, y - 2*r], center = true);

assert(len(QR)*QR_MOD < oy - 2*bot_chamfer - 2, "QR code too large for the box bottom");
assert(QR_DEPTH < stack_h + floor_t - 0.6, "QR inlay too deep");

// ---------------------------------------------------------------------
// QR code, mirrored (x -> -x) so it reads correctly from below
// ---------------------------------------------------------------------
module qr_2d() {
    n = len(QR);
    mirror([1, 0, 0])
        for (r = [0:n-1]) for (c = [0:n-1])
            if (QR[r][c] == "1")
                translate([(c - n/2)*QR_MOD, (n/2 - 1 - r)*QR_MOD]) square(QR_MOD + 0.002);
}

module qr_inlay() linear_extrude(QR_DEPTH) qr_2d();

// ---------------------------------------------------------------------
// box body
// ---------------------------------------------------------------------
module body(qr = false) {
    c = top_chamfer;
    b = bot_chamfer;
    difference() {
        hull() {
            linear_extrude(eps) rrect(ox - 2*b, oy - 2*b, max(r_out - b, 0.2));
            translate([0, 0, b]) linear_extrude(Hb - c - b) rrect(ox, oy, r_out);
            linear_extrude(Hb) rrect(ox - 2*c, oy - 2*c, max(r_out - c, 0.2));
        }
        translate([-ix/2, -iy/2, Hb - iz]) cube([ix, iy, Hb]);
        // snap grooves in the outer long walls
        for (m = [0, 1]) mirror([m, 0, 0])
            translate([ox/2, tab_w/2 + 0.5, 0]) rotate([90, 0, 0])
                linear_extrude(tab_w + 1)
                    polygon([[eps, g0], [-groove_d, g0], [-groove_d, g1], [eps, g1]]);
        if (qr) translate([0, 0, -1]) linear_extrude(QR_DEPTH + 1) qr_2d();
    }
}

// ---------------------------------------------------------------------
// lid (assembled position)
// ---------------------------------------------------------------------
module barb_profile() {   // (u = inward, v = up from the skirt rim)
    polygon(permanent
        ? [[0, v0], [barb, v1], [barb, v2], [0, v2]]   // flat: holds for good
        : [[0, v0], [barb, v2 - barb], [0, v2]]);       // 45° top: pulls off
}

module lid() {
    difference() {
        translate([0, 0, zs]) linear_extrude(skirt_h + Tl) rrect(lx, ly, r_out + fit + skirt_t);
        translate([0, 0, zs - eps]) linear_extrude(skirt_h + eps) rrect(sx, sy, r_out + fit);
        // lead-in chamfer at the skirt rim
        translate([0, 0, zs - eps]) hull() {
            linear_extrude(eps) rrect(sx + 0.8, sy + 0.8, r_out + fit + 0.4);
            linear_extrude(0.4) rrect(sx, sy, r_out + fit);
        }
        // slits that free the snap tabs
        for (m = [0, 1]) mirror([m, 0, 0]) for (s = [-1, 1])
            translate([sx/2 - 1, s * (tab_w/2 + slit/2) - slit/2, zs - 1])
                cube([skirt_t + 2, slit, skirt_h + 1]);
        // stacking recess for the box above, with lead-in chamfer
        if (stack_h > 0) {
            translate([0, 0, H - stack_recess])
                linear_extrude(stack_recess + 1)
                    rrect(ox + 2*stack_clr, oy + 2*stack_clr, r_out + stack_clr);
            translate([0, 0, H - 0.4]) hull() {
                linear_extrude(eps) rrect(ox + 2*stack_clr, oy + 2*stack_clr, r_out + stack_clr);
                translate([0, 0, 0.4]) linear_extrude(eps)
                    rrect(ox + 2*stack_clr + 0.8, oy + 2*stack_clr + 0.8, r_out + stack_clr + 0.4);
            }
        }
    }
    // barbs on the inside of the tabs
    for (m = [0, 1]) mirror([m, 0, 0])
        translate([sx/2, -tab_w/2, zs]) rotate([90, 0, 180])
            linear_extrude(tab_w) barb_profile();
}

module lid_print() translate([0, 0, H]) rotate([180, 0, 0]) lid();

// ---------------------------------------------------------------------
// layout
// ---------------------------------------------------------------------
if (part == "body") body();
else if (part == "body_qr") body(qr = true);
else if (part == "qr") qr_inlay();
else if (part == "lid") lid_print();
else if (part == "assembly")
    for (k = [0:count-1]) translate([0, 0, k * (H - stack_recess)]) {
        color("SteelBlue") body();
        color("Orange") lid();
    }
else if (part == "section")
    difference() {
        union() { color("SteelBlue") body(); color("Orange") lid(); }
        translate([-lx, 0, -1]) cube([2*lx, ly, H + 2]);
    }
else // "all": print plate
    for (k = [0:count-1]) {
        translate([k * (lx + 5), 0, 0]) body();
        translate([k * (lx + 5), ly + 5, 0]) lid_print();
    }
