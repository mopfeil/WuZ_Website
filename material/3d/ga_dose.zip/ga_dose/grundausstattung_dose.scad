// =====================================================================
//  "Grundausstattung" -- screw-lid box for the basic WuZ kit (27.10.2026)
// ---------------------------------------------------------------------
//  Holds
//    * the three Charpentier boxes (v5, stacked 39.5 x 25.5 x 25.9),
//      standing on edge: 25.5 x 25.9 footprint, 39.5 high
//    * the Zener box with the eight symbol chips (D 29.9 x 22.0),
//      upright on top of the Charpentier stack
//    * the pendulum (D 13 x 23.3) and its QR tag (24 x 30 x 2.4)
//    * the trapdoor card folded to A8 (52 x 74), standing upright,
//      74 high, across the box as a divider
//
//  The card sets the size: it stands as a chord off the centre; side A
//  (the larger one) takes Charpentier + Zener box, side B (the narrower
//  segment) pendulum + tag. The inner radius is the smallest one for
//  which the card and each side-A item fit next to each other (closed
//  form, see derived values). Two low rails on the floor hold the card.
//
//  QR code HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/G (unlisted page with an
//  introduction and links to the single tricks) as an inlay in the
//  underside, second filament colour. Load grundausstattung_unterteil.stl
//  and grundausstattung_qr.stl as ONE object with two parts (or open the
//  3MF); for Bambu "Add part -> Load" use grundausstattung_qr_teil.stl.
//
//  Lid lettering "Wissenschaft / und / Zauberkunst" (31.10.2026): inlay
//  TXT_DEPTH deep in the lid top, second colour, same scheme as the QR:
//  grundausstattung_deckel.stl + grundausstattung_schrift.stl as ONE object
//  (or grundausstattung_deckel_schrift.3mf); Bambu "Add part -> Load":
//  grundausstattung_schrift_teil.stl. The lid top lies on the bed, so the
//  lettering is in the first layers and comes out smooth.
//
//  Print: body upright (floor on the bed), lid top on the bed. No supports.
//  Thread code from zener_dose.scad / InverterMagnet_V8.
//    openscad -D 'part="unterteil"' -o grundausstattung_unterteil.stl grundausstattung_dose.scad
//    openscad -D 'part="qr"'        -o grundausstattung_qr.stl        grundausstattung_dose.scad
//    openscad -D 'part="deckel"'    -o grundausstattung_deckel.stl    grundausstattung_dose.scad
//    openscad -D 'part="schrift"'   -o grundausstattung_schrift.stl   grundausstattung_dose.scad
// =====================================================================

/* [Selection] */
part = "druckplatte"; // [baugruppe, schnitt, offen, unterteil, qr, deckel, schrift, deckel_oben, druckplatte]

/* [Contents] */
CARD    = [52, 74];    // folded trapdoor card (A8): width, height
CARD_T  = 1.6;         // thickness of the folded card (assumed, 4 layers)
CHARP   = [25.5, 25.9, 39.5];  // Charpentier stack on edge: x, y, height
ZENER   = [29.9, 22.0];        // Zener box: diameter, height
PENDEL  = [13.0, 23.3];        // pendulum: diameter, height
TAG     = [24, 30, 2.4];       // pendulum QR tag: width, height, thickness
CLR     = 0.5;         // play around every item
CARD_CLR = 0.5;        // play at each card edge (sideways) and above it

/* [Box] */
FLOOR      = 1.6;      // floor (8 layers), QR inlay 0.6 inside
WALL       = 1.2;      // wall well -- thread root
LID_TOP    = 1.6;      // lid plate
SKIRT_WALL = 2.0;      // lid wall outside the inner thread
SEAM       = 0.3;      // gap between lid skirt and body shoulder
CHAMFER    = 0.8;      // outer chamfers

/* [Card rails] */
SLOT    = CARD_T + 0.6;  // slot between the rails
RAIL_W  = 1.2;           // rail width
RAIL_H  = 3.0;           // rail height
RAIL_X0 = 18;            // rails start at |x| = RAIL_X0 (clear of the Charpentier stack)

/* [QR code in the floor] */
QR_ON    = true;
QR_MOD   = 1.2;        // module size (25 modules -> 30 mm)
QR_DEPTH = 0.6;        // inlay depth (3 layers of 0.2)
// HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/G, version 2-M (segno), alphanumeric
// (upper case, HTTP so 38 characters fit). Row 0 = top, "1" = dark module.
QR = [
    "1111111011101101001111111",
    "1000001011010110101000001",
    "1011101011110111001011101",
    "1011101000010001101011101",
    "1011101010011001001011101",
    "1000001000000101001000001",
    "1111111010101010101111111",
    "0000000001111110000000000",
    "1001111110100001010010111",
    "0100110000001111111001100",
    "1000101011101101000010001",
    "1111100100111101001001010",
    "1010101011101111111010010",
    "1000000101100010011010100",
    "1101011011010001011010100",
    "1011100011010011000101011",
    "1011101100111010111110111",
    "0000000010100010100011000",
    "1111111010000010101010111",
    "1000001010010001100011010",
    "1011101011111111111110001",
    "1011101010111000000110011",
    "1011101001001001101000111",
    "1000001001110001100011110",
    "1111111011010011101011111"
];

/* [Lettering on the lid] */
TXT_ON    = true;
TXT       = ["Wissenschaft", "und", "Zauberkunst"];
TXT_SIZE  = [6.6, 4.8, 6.6];   // text() size per line
TXT_Y     = [9.0, 0, -9.0];    // line centres
TXT_FONT  = "Roboto Condensed:style=Bold";
TXT_DEPTH = 0.6;               // inlay depth (3 layers of 0.2)
RING_ON   = true;              // thin frame ring near the rim
RING_R    = 29.2;              // ring centre radius
RING_W    = 0.8;               // ring width (2 lines of a 0.4 nozzle)

/* [Thread] */
THREAD_L = 6.0;        // thread length (3 turns)
P     = 2.0;           // pitch
H_TH  = 1.0;           // thread depth (radial)
TH_CLR = 0.35;         // radial play of the inner thread

/* [Knurl] */
KNURL_N = 48;
KNURL_R = 1.0;

/* [Resolution] */
TH_SEG = 160;
TH_DZ  = 0.125;
$fn = 128;

// ---------- derived values ----------
// Card: near face at y = c (c < 0), occupies [c, c + SLOT], half width WC.
// Side-A item with half width a, reaching K beyond the card face:
// corner (a, c + K) on the circle and card corner (WC, c) on the circle
//   -> WC^2 + c^2 = a^2 + (c + K)^2  ->  c = (WC^2 - a^2 - K^2) / (2K)
WC = CARD[0]/2 + CARD_CLR;
function c_for(a, K) = (WC*WC - a*a - K*K) / (2*K);
K_CH = SLOT + CLR + CHARP[1] + 2*CLR;          // Charpentier, depth + play
K_ZE = SLOT + CLR + ZENER[0] + 2*CLR;          // Zener box (circle: a = 0)
C_CH = c_for(CHARP[0]/2 + CLR, K_CH);
C_ZE = c_for(0, K_ZE);
R_NEED = max(sqrt(WC*WC + C_CH*C_CH), sqrt(WC*WC + C_ZE*C_ZE));
R_IN   = ceil(R_NEED*10)/10;                   // inner radius
CARD_Y = -sqrt(R_IN*R_IN - WC*WC);             // card near face (side B below)
SIDE_B = R_IN + CARD_Y;                        // depth of the side-B segment

WELL_H = CARD[1] + CARD_CLR;                   // inner height, floor -> lid plate
R_MIN  = R_IN + WALL;                          // thread root
D_MAJ  = 2*(R_MIN + H_TH);
GRIP_D = 2*(R_MIN + H_TH + TH_CLR + SKIRT_WALL);
Z_SH   = -THREAD_L - SEAM;
Z_BOT  = -WELL_H - FLOOR;
echo(R_IN = R_IN, inner_d = 2*R_IN, card_y = CARD_Y, side_b = SIDE_B,
     GRIP_D = GRIP_D, total_h = LID_TOP - Z_BOT);
EPS = 0.01;

assert(SIDE_B >= TAG[2] + PENDEL[0] + 3*CLR, "pendulum + tag do not fit on side B");
assert(ZENER[1] + CHARP[2] <= WELL_H, "Charpentier + Zener box too high");
assert(PENDEL[1] + TAG[1] <= WELL_H, "pendulum + tag too high");
assert(!QR_ON || len(QR)*QR_MOD*sqrt(2)/2 < GRIP_D/2 - CHAMFER - 0.5, "QR code reaches the chamfer");
assert(!QR_ON || QR_DEPTH < FLOOR - 0.6, "QR inlay too deep for the floor");
assert(!TXT_ON || TXT_DEPTH < LID_TOP - 0.6, "lettering too deep for the lid plate");
assert(!RING_ON || RING_R + RING_W/2 < GRIP_D/2 - CHAMFER - KNURL_R/2 - 0.8, "ring reaches the knurl");

// ===================================================================
//  Thread polyhedron (from zener_dose.scad): r(a,z) = r_min + H*profile(u)
//  Trapezoid ~60 deg, right-handed.
// ===================================================================
function clamp01(x) = min(1, max(0, x));
function tprofile(u) = clamp01((abs(u - 0.5)*2 - 0.2) / 0.6);
function frac(x) = x - floor(x);

function th_r(a, z, rmin, H, z0, z1, cone_top, lead_in, p = P) =
    let(u  = frac((z - z0)/p - a/360),
        r0 = rmin + H*tprofile(u),
        r1 = cone_top > 0 ? max(min(r0, cone_top + (z1 - z)), rmin) : r0,
        r2 = len(lead_in) == 2 ? max(r1, lead_in[1] - (z - lead_in[0])) : r1)
    r2;

module thread_body(rmin, H, z0, z1, cone_top = -1, lead_in = [], p = P) {
    nz = round((z1 - z0)/TH_DZ) + 1;
    na = TH_SEG;
    pts = concat(
        [for (j = [0:nz-1]) for (i = [0:na-1])
            let(z = z0 + (z1 - z0)*j/(nz-1), a = 360*i/na,
                r = th_r(a, z, rmin, H, z0, z1, cone_top, lead_in, p))
            [r*cos(a), r*sin(a), z]],
        [[0, 0, z0], [0, 0, z1]]);
    cb = nz*na; ct = cb + 1;
    function id(j, i) = j*na + (i % na);
    faces = concat(
        [for (j = [0:nz-2]) for (i = [0:na-1]) each [
            [id(j,i), id(j+1,i+1), id(j,i+1)],
            [id(j,i), id(j+1,i),   id(j+1,i+1)]]],
        [for (i = [0:na-1]) [cb, id(0,i), id(0,i+1)]],
        [for (i = [0:na-1]) [ct, id(nz-1,i+1), id(nz-1,i)]]);
    polyhedron(points = pts, faces = faces, convexity = 10);
}

module knurl(z0, h, d = GRIP_D, n = KNURL_N, r = KNURL_R) {
    for (k = [0:n-1])
        rotate([0, 0, 360*k/n])
            translate([d/2 + r/2, 0, z0 - 1])
                cylinder(h = h + 2, r = r, $fn = 24);
}

// ---------- card rails on the floor (both card ends) ----------
module rails() {
    intersection() {
        for (s = [-1, 1]) for (y = [CARD_Y - RAIL_W, CARD_Y + SLOT])
            translate([s > 0 ? RAIL_X0 : -R_IN - 1, y, -WELL_H - EPS])
                cube([R_IN + 1 - RAIL_X0, RAIL_W, RAIL_H + EPS]);
        translate([0, 0, -WELL_H - 1]) cylinder(h = RAIL_H + 2, r = R_IN + EPS);
    }
}

// ---------- body (top rim = z 0) ----------
module unterteil() {
    h = Z_SH - Z_BOT;
    difference() {
        union() {
            intersection() {
                difference() {
                    translate([0, 0, Z_BOT]) cylinder(h = h, d = GRIP_D);
                    knurl(Z_BOT, h);
                }
                translate([0, 0, Z_BOT]) cylinder(h = h, r1 = GRIP_D/2 - CHAMFER, r2 = GRIP_D/2 - CHAMFER + h);
            }
            thread_body(R_MIN, H_TH, Z_SH - EPS, 0, cone_top = D_MAJ/2 - 0.6);
        }
        translate([0, 0, -WELL_H]) cylinder(h = WELL_H + 1, r = R_IN);
        translate([0, 0, -0.4]) cylinder(h = 0.4 + EPS, r1 = R_IN, r2 = R_IN + 0.4);
        if (QR_ON) translate([0, 0, Z_BOT - 1]) linear_extrude(QR_DEPTH + 1) qr_2d();
    }
    rails();
}

// ---------- QR code ----------
// Mirrored (x -> -x) so it reads correctly when the box is turned over.
module qr_2d() {
    n = len(QR);
    mirror([1, 0, 0])
        for (r = [0:n-1]) for (c = [0:n-1])
            if (QR[r][c] == "1")
                translate([(c - n/2)*QR_MOD, (n/2 - 1 - r)*QR_MOD]) square(QR_MOD + 0.002);
}

module qr_inlay() translate([0, 0, Z_BOT]) linear_extrude(QR_DEPTH) qr_2d();

// ---------- lettering on the lid (reads from above) ----------
module schrift_2d() {
    for (i = [0:len(TXT)-1])
        translate([0, TXT_Y[i]])
            text(TXT[i], size = TXT_SIZE[i], font = TXT_FONT,
                 halign = "center", valign = "center");
    if (RING_ON) difference() {
        circle(r = RING_R + RING_W/2, $fn = 256);
        circle(r = RING_R - RING_W/2, $fn = 256);
    }
}

module schrift_inlay() translate([0, 0, LID_TOP - TXT_DEPTH]) linear_extrude(TXT_DEPTH) schrift_2d();

// ---------- lid (plate underside = z 0) ----------
module deckel() {
    z0 = Z_SH + SEAM; h = LID_TOP - z0;
    difference() {
        intersection() {
            difference() {
                translate([0, 0, z0]) cylinder(h = h, d = GRIP_D);
                knurl(z0, h);
            }
            translate([0, 0, z0]) cylinder(h = h, r1 = GRIP_D/2 - CHAMFER + h, r2 = GRIP_D/2 - CHAMFER);
        }
        thread_body(R_MIN + TH_CLR, H_TH, Z_SH - P, EPS,
                    lead_in = [z0, D_MAJ/2 + TH_CLR + 0.6]);
        if (TXT_ON) translate([0, 0, LID_TOP - TXT_DEPTH]) linear_extrude(TXT_DEPTH + 1) schrift_2d();
    }
}

// ---------- contents (preview only) ----------
module inhalt() {
    zf = -WELL_H;
    ya = CARD_Y + SLOT + CLR;                       // side A starts here
    color("Khaki") translate([-CARD[0]/2, CARD_Y + (SLOT - CARD_T)/2, zf])
        cube([CARD[0], CARD_T, CARD[1]]);
    color("SteelBlue") translate([-CHARP[0]/2, ya + CLR, zf]) cube(CHARP);
    color("Gold") translate([0, ya + CLR + ZENER[0]/2, zf + CHARP[2]])
        cylinder(h = ZENER[1], d = ZENER[0]);
    color("IndianRed") translate([-TAG[0]/2, CARD_Y - CLR - TAG[2], zf])
        cube([TAG[0], TAG[2], TAG[1]]);
    color("DimGray") translate([0, CARD_Y - CLR - TAG[2] - CLR - PENDEL[0]/2, zf])
        cylinder(h = PENDEL[1], d = PENDEL[0]);
}

module half(cut) {
    if (cut) difference() { children(); translate([0, -200, -200]) cube(400); }
    else children();
}

module baugruppe(cut = false) {
    color("Tan") half(cut) unterteil();
    if (QR_ON) color("Black") half(cut) qr_inlay();
    color("DarkSeaGreen", cut ? 1 : 0.5) half(cut) deckel();
    if (TXT_ON) color("Black") half(cut) schrift_inlay();
    inhalt();
}

// ---------- output ----------
module lid_print() rotate([180, 0, 0]) translate([0, 0, -LID_TOP]) deckel();   // top on the bed
module schrift_print() rotate([180, 0, 0]) translate([0, 0, -LID_TOP]) schrift_inlay();

if (part == "unterteil") translate([0, 0, -Z_BOT]) unterteil();
else if (part == "qr") translate([0, 0, -Z_BOT]) qr_inlay();
else if (part == "deckel") lid_print();
else if (part == "schrift") schrift_print();
else if (part == "deckel_oben") { color("DarkSeaGreen") deckel(); if (TXT_ON) color("Black") schrift_inlay(); }
else if (part == "baugruppe") baugruppe();
else if (part == "schnitt") baugruppe(cut = true);
else if (part == "offen") { color("Tan") unterteil(); inhalt(); }   // top view without lid
else if (part == "druckplatte") {
    translate([0, 0, -Z_BOT]) unterteil();
    if (QR_ON) translate([0, 0, -Z_BOT]) qr_inlay();
    translate([GRIP_D + 5, 0, 0]) lid_print();
    if (TXT_ON) translate([GRIP_D + 5, 0, 0]) schrift_print();
}
