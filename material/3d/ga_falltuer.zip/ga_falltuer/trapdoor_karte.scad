// =====================================================================
//  Trapdoor card ("Die Falltuer") as a two-colour print (30.10.2026)
// ---------------------------------------------------------------------
//  Geometry from trapdoor_print.pptx (120 x 80 card): 4 columns of W/4,
//  fold lines at H/4 and 3H/4, door = column 2 x middle half
//  (W/4 x H/2), cut on three sides, hinged on the centre line x = W/2.
//  The grid scales with the card, so any size works; default postcard
//  A6 148 x 105.
//
//  Why a thin sheet and not rigid panels with film hinges: in the
//  booklet photos (steps 11, 12) the panels themselves bend while the
//  card turns through the door. Rigid panels would block that. So the
//  card is a flexible sheet (T 0.6) and every fold line is a groove from
//  BOTH sides (web 0.3 in the middle), so it folds flat either way.
//
//  Colours: lower half A side "B" (back), upper half "A" (front).
//  DOOR_SWAP = true: the door is stacked the other way round, i.e. it
//  shows the opposite colour on each side. After the trick the door has
//  turned over, so its colour matches the card again (and vice versa
//  with DOOR_SWAP = false: plain card, door changes colour).
//
//  Print: PETG (PLA webs crack after a few folds), layer 0.15 incl.
//  first layer, so every colour is 2 layers and the web is 1 + 1.
//  Load trapdoor_karte_a.stl and trapdoor_karte_b.stl as ONE object
//  with two parts, or open the 3MF.
//    openscad -D 'part="a"' -o trapdoor_karte_a.stl trapdoor_karte.scad
//    openscad -D 'part="b"' -o trapdoor_karte_b.stl trapdoor_karte.scad
// =====================================================================

part = "both";          // "a" | "b" | "both"

W = 148;                // card width  (postcard A6)
H = 105;                // card height
T = 0.6;                // sheet thickness (4 layers of 0.15)
CR = 2;                 // corner radius
DOOR_SWAP = true;       // door in the opposite colour

GW = 1.0;               // groove width (180 deg fold over web: ~pi*T/2)
GD = 0.15;              // groove depth per side -> web T - 2*GD = 0.3
SLIT = 0.5;             // cut around the door (paper: 0)

// --- derived ---------------------------------------------------------
X1 = W/4; X2 = W/2; X3 = 3*W/4;
Y1 = H/4; Y2 = 3*H/4;
ZM = T/2;               // colour boundary
E = 0.01;

module sheet2d()
    offset(r = CR) offset(delta = -CR) square([W, H]);

// door outline (inner edge of the slit)
module door2d()
    translate([X1 + SLIT/2, Y1 + SLIT/2]) square([X2 - X1 - SLIT/2, Y2 - Y1 - SLIT]);

// slit = U around the door, open at the hinge
module slit2d()
    difference() {
        translate([X1 - SLIT/2, Y1 - SLIT/2]) square([X2 - X1 + SLIT/2, Y2 - Y1 + SLIT]);
        door2d();
    }

// fold lines as segments [x0, y0, x1, y1]
FOLDS = [
    [X1, 0,  X1, Y1], [X1, Y2, X1, H],          // left of door: above / below
    [X2, 0,  X2, H],                            // centre line = door hinge
    [X3, 0,  X3, H],
    [0, Y1, X1, Y1], [X2, Y1, W, Y1],           // door top/bottom edge is cut
    [0, Y2, X1, Y2], [X2, Y2, W, Y2],
];

module grooves2d()
    for (f = FOLDS)
        if (f[0] == f[2]) translate([f[0] - GW/2, f[1] - E]) square([GW, f[3] - f[1] + 2*E]);
        else              translate([f[0] - E, f[1] - GW/2]) square([f[2] - f[0] + 2*E, GW]);

module layer(z0, z1)
    translate([0, 0, z0]) linear_extrude(z1 - z0) children();

// door colour field: ends DC_GAP before the hinge groove, so the web of
// the hinge stays one continuous card stack (no colour seam where it
// bends). Its lower half reaches DC_OVL further, so the colour-A body is
// joined by a face, not just an edge (manifold).
DC_GAP = 1.0;
DC_OVL = 0.1;
XC = X2 - GW/2 - DC_GAP;
module doorc2d(ext = 0)
    translate([X1, Y1]) square([XC - X1 + ext, Y2 - Y1]);

module half(z0, z1) layer(z0, z1) difference() { intersection() { sheet2d(); children(); } slit2d(); }

module grooves() {
    translate([0, 0, -E])     linear_extrude(GD + E) grooves2d();
    translate([0, 0, T - GD]) linear_extrude(GD + E) grooves2d();
}

module colour_a() difference() {        // front colour
    if (DOOR_SWAP) union() {
        half(ZM, T) difference() { square([W, H]); doorc2d(); }
        half(0, ZM) doorc2d(DC_OVL);
    } else half(ZM, T) square([W, H]);
    grooves();
}
module colour_b() difference() {        // back colour
    if (DOOR_SWAP) union() {
        half(0, ZM) difference() { square([W, H]); doorc2d(DC_OVL); }
        half(ZM, T) doorc2d();
    } else half(0, ZM) square([W, H]);
    grooves();
}

if (part == "a") colour_a();
else if (part == "b") colour_b();
else { color("gold") colour_a(); color("#203050") colour_b(); }
