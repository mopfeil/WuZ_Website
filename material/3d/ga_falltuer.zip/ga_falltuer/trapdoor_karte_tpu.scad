// =====================================================================
//  Trapdoor card ("Die Falltuer"), three-material print (03.11.2026)
//  derived from wuz/.../3D_Druck/trapdoor_karte/trapdoor_karte.scad
// ---------------------------------------------------------------------
//  Same card as the PETG-only version (grid, door, DOOR_SWAP, 4 layers),
//  but every fold is now a TPU hinge instead of a thin PETG web.
//
//  Layer stack, 4 layers of LH (LH = 0.16 as in the X2D profile, also for
//  the first layer):
//
//      layer 4  colour A skin          (groove over the fold)
//      layer 3  colour A  | TPU band   (band = HW wide around fold)
//      layer 2  colour B  | TPU band
//      layer 1  colour B skin          (groove under the fold)
//
//  Inside the band the TPU replaces the PETG core; the PETG skins lie on
//  top and below it (lap joint, (HW-GW)/2 per side and face), so TPU and
//  PETG are bonded over an area, not only at a butt seam. In the groove
//  (width GW) only the TPU core remains: that is the hinge (2 layers TPU).
//  Outside the bands nothing changes: the panels are 0.6 mm PETG and can
//  still bend while the card goes through the door.
//
//  Door: DOOR_SWAP as before (door stacked the other way round). The
//  hinge on x = W/2 is TPU now, so the door colour field can run right
//  up to the groove; the colour seam no longer lies in the bend.
//
//  Parts (one object, three parts / filaments):
//    a   = colour A (front)  PETG
//    b   = colour B (back)   PETG
//    tpu = hinge bands       TPU (95A or softer)
//    openscad -D 'part="a"'   -o trapdoor_karte_tpu_a.stl   trapdoor_karte_tpu.scad
//    openscad -D 'part="b"'   -o trapdoor_karte_tpu_b.stl   trapdoor_karte_tpu.scad
//    openscad -D 'part="tpu"' -o trapdoor_karte_tpu_tpu.stl trapdoor_karte_tpu.scad
// =====================================================================

part = "all";           // "a" | "b" | "tpu" | "all"

W = 148;                // card width  (postcard A6)
H = 105;                // card height
LH = 0.16;              // layer height of the slicer profile (bambu/*.config)
T = 4*LH;               // sheet thickness (4 layers)
TS = LH;                // PETG skin over/under the TPU band (1 layer)
CR = 2;                 // corner radius
DOOR_SWAP = true;       // door in the opposite colour

GW = 1.2;               // groove width = free TPU hinge length
HW = 6.0;               // TPU band width (lap 2.4 mm per side)
SLIT = 0.5;             // cut around the door

// --- derived ---------------------------------------------------------
X1 = W/4; X2 = W/2; X3 = 3*W/4;
Y1 = H/4; Y2 = 3*H/4;
ZM = T/2;               // colour boundary
Z1 = TS; Z2 = T - TS;   // TPU core
E = 0.01;

module sheet2d()
    offset(r = CR) offset(delta = -CR) square([W, H]);

module door2d()
    translate([X1 + SLIT/2, Y1 + SLIT/2]) square([X2 - X1 - SLIT/2, Y2 - Y1 - SLIT]);

module slit2d()
    difference() {
        translate([X1 - SLIT/2, Y1 - SLIT/2]) square([X2 - X1 + SLIT/2, Y2 - Y1 + SLIT]);
        door2d();
    }

FOLDS = [
    [X1, 0,  X1, Y1], [X1, Y2, X1, H],          // left of door: above / below
    [X2, 0,  X2, H],                            // centre line = door hinge
    [X3, 0,  X3, H],
    [0, Y1, X1, Y1], [X2, Y1, W, Y1],           // door top/bottom edge is cut
    [0, Y2, X1, Y2], [X2, Y2, W, Y2],
];

module strips2d(w)
    for (f = FOLDS)
        if (f[0] == f[2]) translate([f[0] - w/2, f[1] - E]) square([w, f[3] - f[1] + 2*E]);
        else              translate([f[0] - E, f[1] - w/2]) square([f[2] - f[0] + 2*E, w]);

module card2d() difference() { sheet2d(); slit2d(); }

// door colour field (cut back by the slit and the groove anyway)
module door_field2d() if (DOOR_SWAP) translate([X1, Y1]) square([X2 - X1, Y2 - Y1]);

module layer(z0, z1) translate([0, 0, z0]) linear_extrude(z1 - z0) children();

// region helpers: card minus door field (main) / door field only (door)
module main2d() difference() { card2d(); door_field2d(); }
module door2d_c() intersection() { card2d(); door_field2d(); }

// one colour: "upper" = sits in the top half on the main card
module colour(upper) {
    zs = upper ? [Z2, T, ZM, Z2] : [0, Z1, Z1, ZM];   // skin, core on main card
    zd = upper ? [0, Z1, Z1, ZM] : [Z2, T, ZM, Z2];   // same on the door
    layer(zs[0], zs[1]) difference() { main2d(); strips2d(GW); }
    layer(zs[2], zs[3]) difference() { main2d(); strips2d(HW); }
    if (DOOR_SWAP) {
        layer(zd[0], zd[1]) difference() { door2d_c(); strips2d(GW); }
        layer(zd[2], zd[3]) difference() { door2d_c(); strips2d(HW); }
    }
}

module tpu() layer(Z1, Z2) intersection() { card2d(); strips2d(HW); }

if (part == "a") colour(true);
else if (part == "b") colour(false);
else if (part == "tpu") tpu();
else {
    color("gold") colour(true);
    color("#203050") colour(false);
    color("white") tpu();
}
