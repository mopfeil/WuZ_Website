// Jastrow-Täuschung, Variante 2 „flacher Bogen“ (20.11.2026)
// Form angelehnt an David Regal, „The Long & Short of It“ (Murphy's), aus den Produktfotos
// abgeschätzt: Öffnungswinkel ca. 32°, Breite ca. 0,38 × Sehnenlänge (Innen-/Außenradius ≈ 0,79),
// gerade radiale Enden mit schwarzem Streifen, Schrift „KURZ“/„LANG“ OBEN, Buchstaben gesperrt
// entlang des Bogens.
//
// Drei Größen: SIZE = "gross" (Außensehne 200 mm) | "klein" (100 mm)
//   | "mini" (35 mm, passt als Stapel 2 Kurz + 2 Lang in die Grundausstattungs-Dose,
//     flach über Anhänger und Pendel auf der schmalen Seite, seit 22.11.2026).
// Teile je Größe:
//   kurz : Grundteil, oben „KURZ“            (Filament 1, z. B. Rot)
//   lang : exakt gleich, oben „LANG“         (Filament 2, z. B. Gelb)
//   C    : wie lang, aber VERGLEICH_PROZENT größer, oben „LANG“ (Filament 1)
//   <teil>_einlage : Schrift + Endstreifen, 0,6 bündig in der Oberseite (Filament 3, Schwarz)
// Magnet: EIN durchgehendes Loch für Zylindermagnet 5×5 (5 mm = Teildicke, beidseitig bündig),
// auf der Symmetrieachse knapp über dem Schwerpunkt (Bogen oben aufgehängt) → pendelt sich
// gerade ein. Es liegt in der Lücke zwischen 2. und 3. Buchstaben (seit 20.11. nachmittags;
// vorher zwei Sacklöcher, T 6).
//
// part = "kurz" | "lang" | "C" | "kurz_einlage" | "lang_einlage" | "C_einlage"
//        | "alle" (Vorschau) | "stapel" (Anordnung) | "unten" (Unterseite)

SIZE = "gross";
part = "alle";

function by(g, k, m) = SIZE == "gross" ? g : SIZE == "klein" ? k : m;
CHORD = by(200, 100, 35);             // Außensehne = Länge [mm]
OPEN  = 32;                            // Öffnungswinkel [Grad]
W_REL = 0.38;                          // Breite / Außensehne
T     = 5.0;                           // Dicke = Magnethöhe
CH    = 0.8;                           // Fase oben
FOOT  = 0.3;                           // Fase unten (Elefantenfuß)
RC    = by(2, 1.2, 0.8);              // Eckenradius
VERGLEICH_PROZENT = 6;

TXT_H    = by(26, 13, 4);              // Buchstabenhöhe
TXT_SPAN = by(0.62, 0.62, 0.574);                      // Schrift (außen-außen) / Außensehne
MID_X    = by(0, 2, 2.8);   // mittlere Buchstaben je so weit nach außen (Platz fürs Magnetloch)
TXT_D    = 0.6;                        // Einlagetiefe (3 Schichten à 0,2)
STR_IN   = by(1.5, 1.0, 0.7);// Endstreifen: Abstand zur Endkante
STR_W    = by(4, 2.5, 1.5); // Endstreifen: Breite
STR_M    = by(1.5, 1.0, 0.8);// Endstreifen: Abstand zu Innen-/Außenkante

MAG_D  = 5.2;                          // Magnetloch Ø
MAG_UP = by(4, 2, 1);    // Loch so weit über dem Schwerpunkt [mm, Grundteil]
MAG_CH = 0.4;                          // Fase an der Lochkante unten
$fn = 720;

R_O = CHORD / 2 / sin(OPEN / 2);       // gross: 362,8
W   = CHORD * W_REL;                   // gross: 76
R_I = R_O - W;                         // gross: 286,8
R_M = (R_O + R_I) / 2;
S_C = 1 + VERGLEICH_PROZENT / 100;

// Buchstabenabstand (Mitte–Mitte, als Bogenlänge auf R_M) für 4 Buchstaben
LET_D = (TXT_SPAN * CHORD - 0.75 * TXT_H) / 3;
// Schwerpunkt eines Ringsegments (Abstand vom Bogenmittelpunkt, auf der Symmetrieachse)
HALF = OPEN / 2;
R_S  = 2/3 * (pow(R_O,3) - pow(R_I,3)) / (pow(R_O,2) - pow(R_I,2)) * sin(HALF) / (HALF * PI / 180);
R_MAG = R_S + MAG_UP;
echo(SIZE = SIZE, R_O = R_O, R_I = R_I, Breite = W, Buchstabenabstand = LET_D,
     Schwerpunkt = R_S, Magnetloch = R_MAG);

// 2D-Ringsegment, Symmetrieachse +y, Bogenmittelpunkt im Ursprung, Ecken gerundet
module seg_raw(s = 1) {
    ro = R_O * s; ri = R_I * s;
    a0 = 90 - OPEN / 2; a1 = 90 + OPEN / 2; n = 240;
    polygon(concat(
        [for (i = [0:n]) let(a = a0 + (a1 - a0) * i / n) [ro * cos(a), ro * sin(a)]],
        [for (i = [n:-1:0]) let(a = a0 + (a1 - a0) * i / n) [ri * cos(a), ri * sin(a)]]));
}
module seg2d(s = 1) { offset(r = RC) offset(delta = -RC) seg_raw(s); }

module body(s = 1) {
    steps = 4;
    linear_extrude(FOOT + 0.01) offset(delta = -FOOT) seg2d(s);
    translate([0, 0, FOOT]) linear_extrude(T - FOOT - CH + 0.01) seg2d(s);
    for (i = [0:steps - 1])
        translate([0, 0, T - CH + CH * i / steps])
            linear_extrude(CH / steps + 0.01)
                offset(delta = -CH * (i + 1) / steps) seg2d(s);
}

// Schrift entlang des Bogens (gleiche Größe und Bogenabstände bei C → verrät nichts)
module text2d(txt, s = 1) {
    r = R_M * s;
    for (k = [0:len(txt) - 1]) {
        arc = (k - (len(txt) - 1) / 2) * LET_D + sign(k - (len(txt) - 1) / 2) * MID_X;
        a = -arc / r * 180 / PI;
        rotate(a) translate([0, r])
            text(txt[k], size = TXT_H, font = "Liberation Sans:style=Bold",
                 halign = "center", valign = "center");
    }
}

// Schwarze Endstreifen, parallel zur radialen Endkante
module stripes2d(s = 1) {
    ro = R_O * s - STR_M; ri = R_I * s + STR_M;
    for (side = [-1, 1]) {
        // Winkel der Endkante; Streifen als Sektorstück mit festem Abstand zur Kante
        e = OPEN / 2;
        rotate(side * e)
            intersection() {
                translate([side > 0 ? STR_IN : -STR_IN - STR_W, ri]) square([STR_W, ro - ri]);
                seg_raw(s);
            }
    }
}

module inlay2d(txt, s = 1) { text2d(txt, s); stripes2d(s); }

module inlay(txt, s = 1, eps = 0) {
    difference() {
        translate([0, 0, T - TXT_D]) linear_extrude(TXT_D + eps) inlay2d(txt, s);
        translate([0, R_MAG * s, 0]) cylinder(d = MAG_D, h = 3 * T, center = true, $fn = 64);
    }
}

module magnet_holes(s = 1) {
    translate([0, R_MAG * s, 0]) {
        translate([0, 0, -1]) cylinder(d = MAG_D, h = T + 2, $fn = 64);
        translate([0, 0, -0.01]) cylinder(d1 = MAG_D + 2 * MAG_CH, d2 = MAG_D, h = MAG_CH + 0.01, $fn = 64);
    }
}

module piece(txt, s = 1) {
    difference() { body(s); inlay(txt, s, 0.01); magnet_holes(s); }
}

module kurz()     piece("KURZ");
module lang()     piece("LANG");
module groesser() piece("LANG", S_C);

module place(s) { translate([0, -R_I * s, 0]) children(); }

if (part == "kurz") kurz();
if (part == "lang") lang();
if (part == "C")    groesser();
if (part == "kurz_einlage") inlay("KURZ");
if (part == "lang_einlage") inlay("LANG");
if (part == "C_einlage")    inlay("LANG", S_C);
if (part == "alle") {
    G = CHORD * 1.12;
    color("crimson") place(1) kurz();             color("black") place(1) inlay("KURZ", 1, 0.02);
    translate([0, -W * 1.4, 0]) {
        color("gold") place(1) lang();            color("black") place(1) inlay("LANG", 1, 0.02);
    }
    translate([0, -W * 2.8, 0]) {
        color("crimson") place(S_C) groesser();   color("black") place(S_C) inlay("LANG", S_C, 0.02);
    }
}
if (part == "stapel") {   // Jastrow-Anordnung: LANG oben, KURZ darunter, dicht
    translate([0, W + CHORD * 0.05, 0]) {
        color("gold") place(1) lang();            color("black") place(1) inlay("LANG", 1, 0.02);
    }
    color("crimson") place(1) kurz();             color("black") place(1) inlay("KURZ", 1, 0.02);
}
if (part == "unten") rotate([0, 180, 0]) color("crimson") place(1) kurz();
