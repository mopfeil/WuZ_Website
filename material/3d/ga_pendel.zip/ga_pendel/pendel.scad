// =====================================================================
//  Pendulum, two parts screwed together (15.10.2026)
// ---------------------------------------------------------------------
//  Plumb-bob shape, outer diameter 13, length about 23.
//  - Lower part: cone with the tip at the bottom, magnet pocket for a
//    cylindrical magnet 5 x 5 just above the tip, inner thread on top.
//  - Cap: threaded spigot downwards, thread hole in the top. The thread
//    goes through the hole into the knot chamber and is held by a knot.
//    The knot chamber (d 3.5) is narrower than the magnet, so the spigot
//    end also closes the magnet pocket (MAG_PLAY of axial play).
//  Assembly: thread through the top hole, tie a knot at the open spigot
//  end, pull it back into the chamber, drop the magnet into the lower
//  part, screw together.
//
//  Print (no supports): cap upside down (flat top on the bed, spigot up),
//  lower part upside down (joint face on the bed, tip up). All inner
//  ceilings are 45 deg cones.
//  Thread code from zener_dose.scad / InverterMagnet_V8.
//    openscad -D 'part="unterteil"' -o pendel_unterteil.stl pendel.scad
//    openscad -D 'part="kappe"'     -o pendel_kappe.stl     pendel.scad
// =====================================================================

/* [Selection] */
part = "druckplatte"; // [baugruppe, schnitt, unterteil, kappe, druckplatte]

/* [Magnet] */
MAG_D    = 5.0;
MAG_H    = 5.0;
MAG_CLR  = 0.15;   // radial play in the pocket
MAG_PLAY = 0.3;    // axial play between pocket floor and spigot end

/* [Thread hole and knot] */
HOLE_D   = 1.4;    // thread hole in the top
TOP_WALL = 1.2;    // material above the knot chamber
KNOT_D   = 3.5;    // knot chamber (must stay < MAG_D)

/* [Body] */
OUTER_D   = 13.0;
CAP_CYL   = 2.0;   // cylindrical part of the cap above the joint
CAP_H     = 6.0;   // cap height above the joint
TOP_D     = 5.0;   // flat top
LOW_CYL   = 8.0;   // cylindrical part of the lower part below the joint
CONE_HALF = 35;    // half angle of the tip cone
TIP_R     = 0.8;   // rounded tip
EDGE      = 0.4;   // chamfer at the joint

/* [Thread] */
THREAD_L = 5.0;    // spigot length
P        = 1.25;   // pitch
H_TH     = 0.7;    // thread depth (radial)
R_MIN    = 3.2;    // spigot thread root
CLR      = 0.3;    // radial play of the inner thread
BORE_EXTRA = 0.4;  // inner thread deeper than the spigot

TH_SEG = 128;
TH_DZ  = 0.125;

$fn = 96;
EPS = 0.01;

// ---------- derived ----------
R_OUT   = OUTER_D/2;
MAG_R   = MAG_D/2 + MAG_CLR;                        // 2.65
Z_SPIG  = -THREAD_L;                                // spigot end
Z_MAG   = Z_SPIG - MAG_PLAY - MAG_H;                // pocket floor
Z_CONE  = -LOW_CYL;                                 // start of the tip cone
CONE_L  = R_OUT / tan(CONE_HALF);
Z_TIP   = Z_CONE - CONE_L;
function r_cone(z) = R_OUT * (z - Z_TIP) / CONE_L;  // outer radius in the cone

echo(length = CAP_H - Z_TIP, thread_d = 2*(R_MIN + H_TH),
     wall_at_thread = R_OUT - (R_MIN + H_TH + CLR),
     wall_at_pocket_floor = r_cone(Z_MAG) - MAG_R,
     wall_below_pocket = (Z_MAG - MAG_R) - Z_TIP);

assert(KNOT_D < MAG_D - 0.6, "knot chamber must be narrower than the magnet");
assert(MAG_R < R_MIN + CLR - 0.3, "magnet pocket wider than the thread bore");
assert(r_cone(Z_MAG) - MAG_R >= 1.2, "wall around the pocket floor too thin");
assert(CAP_H - TOP_WALL > CAP_CYL, "knot chamber too short");

// ===================================================================
//  Thread polyhedron (from zener_dose.scad): r(a,z) = r_min + H*profile(u)
//  cone_top : 45 deg lead chamfer at the top end (outer thread), -1 = off
//  lead_in  : [z_ref, r_ref] 45 deg widening downwards (inner thread), [] = off
// ===================================================================
function clamp01(x) = min(1, max(0, x));
function tprofile(u) = clamp01((abs(u - 0.5)*2 - 0.2) / 0.6);
function frac(x) = x - floor(x);

function th_r(a, z, rmin, H, z0, z1, cone_top, lead_in, p = P) =
    let(u  = frac((z - z0)/p - a/360),
        r0 = rmin + H*tprofile(u),
        r1 = cone_top > 0 ? max(min(r0, cone_top + (z1 - z)), rmin) : r0,
        r2 = len(lead_in) == 2 ? max(r1, lead_in[1] - (z - lead_in[0])) : r1)
    r2;

module thread_body(rmin, H, z0, z1, cone_top = -1, lead_in = [], p = P) {
    nz = round((z1 - z0)/TH_DZ) + 1;
    na = TH_SEG;
    pts = concat(
        [for (j = [0:nz-1]) for (i = [0:na-1])
            let(z = z0 + (z1 - z0)*j/(nz-1), a = 360*i/na,
                r = th_r(a, z, rmin, H, z0, z1, cone_top, lead_in, p))
            [r*cos(a), r*sin(a), z]],
        [[0, 0, z0], [0, 0, z1]]);
    cb = nz*na; ct = cb + 1;
    function id(j, i) = j*na + (i % na);
    faces = concat(
        [for (j = [0:nz-2]) for (i = [0:na-1]) each [
            [id(j,i), id(j+1,i+1), id(j,i+1)],
            [id(j,i), id(j+1,i),   id(j+1,i+1)]]],
        [for (i = [0:na-1]) [cb, id(0,i), id(0,i+1)]],
        [for (i = [0:na-1]) [ct, id(nz-1,i+1), id(nz-1,i)]]);
    polyhedron(points = pts, faces = faces, convexity = 10);
}

// Both threads are built pointing up and turned over with rotate (not
// mirror), so both stay right-handed.

// ---------- lower part (joint face = z 0) ----------
module unterteil() {
    rb = R_MIN + CLR;                    // bore minor radius
    difference() {
        union() {
            // cylinder with chamfer at the joint
            translate([0, 0, Z_CONE - EPS])
                cylinder(h = LOW_CYL - EDGE + EPS, r = R_OUT);
            translate([0, 0, -EDGE - EPS])
                cylinder(h = EDGE + EPS, r1 = R_OUT, r2 = R_OUT - EDGE);
            // tip cone with rounded tip
            hull() {
                translate([0, 0, Z_CONE]) cylinder(h = EPS, r = R_OUT);
                translate([0, 0, Z_TIP + TIP_R/sin(CONE_HALF)]) sphere(r = TIP_R);
            }
        }
        // inner thread, opening at the top with a 45 deg lead-in
        rotate([180, 0, 0])
            thread_body(rb, H_TH, -EPS, THREAD_L + BORE_EXTRA,
                        lead_in = [0, rb + H_TH + 0.5]);
        // 45 deg floor of the bore down to the pocket
        translate([0, 0, -THREAD_L - BORE_EXTRA - (rb - MAG_R) + EPS])
            cylinder(h = rb - MAG_R, r1 = MAG_R, r2 = rb);
        // magnet pocket with 45 deg cone floor
        translate([0, 0, Z_MAG]) cylinder(h = -Z_MAG, r = MAG_R);
        translate([0, 0, Z_MAG - MAG_R + EPS]) cylinder(h = MAG_R, r1 = 0, r2 = MAG_R);
    }
}

// ---------- cap (joint face = z 0) ----------
module kappe() {
    difference() {
        union() {
            translate([0, 0, EDGE]) cylinder(h = CAP_CYL - EDGE + EPS, r = R_OUT);
            cylinder(h = EDGE + EPS, r1 = R_OUT - EDGE, r2 = R_OUT);
            translate([0, 0, CAP_CYL])
                cylinder(h = CAP_H - CAP_CYL, r1 = R_OUT, r2 = TOP_D/2);
            // threaded spigot, chamfered end
            rotate([180, 0, 0])
                thread_body(R_MIN, H_TH, -EPS, THREAD_L, cone_top = R_MIN + 0.2);
        }
        // knot chamber, open at the spigot end
        translate([0, 0, Z_SPIG - 1]) cylinder(h = CAP_H - TOP_WALL - Z_SPIG + 1, d = KNOT_D);
        // 45 deg ceiling of the chamber into the thread hole
        translate([0, 0, CAP_H - TOP_WALL - EPS])
            cylinder(h = (KNOT_D - HOLE_D)/2, d1 = KNOT_D, d2 = HOLE_D);
        // thread hole with a small countersink at the top
        cylinder(h = CAP_H + 1, d = HOLE_D);
        translate([0, 0, CAP_H - 0.4]) cylinder(h = 0.4 + EPS, d1 = HOLE_D, d2 = HOLE_D + 0.8);
    }
}

// ---------- view ----------
module half(cut) {
    if (cut) difference() { children(); translate([-50, -100, -50]) cube(100); }
    else children();
}

module baugruppe(cut = false) {
    color("SteelBlue") half(cut) unterteil();
    color("LightSteelBlue") half(cut) kappe();
    color("DimGray") half(cut) translate([0, 0, Z_MAG]) cylinder(h = MAG_H, d = MAG_D);
}

// ---------- output ----------
module kappe_print()     rotate([180, 0, 0]) translate([0, 0, -CAP_H]) kappe();   // top on the bed
module unterteil_print() rotate([180, 0, 0]) unterteil();                        // joint on the bed

if (part == "unterteil") unterteil_print();
else if (part == "kappe") kappe_print();
else if (part == "baugruppe") baugruppe();
else if (part == "schnitt") baugruppe(cut = true);
else if (part == "druckplatte") {
    unterteil_print();
    translate([OUTER_D + 5, 0, 0]) kappe_print();
}
