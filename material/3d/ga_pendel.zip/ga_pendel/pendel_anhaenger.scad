// =====================================================================
//  Pendulum grip tag with QR code (26.10.2026)
// ---------------------------------------------------------------------
//  The pendulum itself (d 13) is too small for a readable QR code, so the
//  code sits on a flat tag at the UPPER end of the thread: tie the thread
//  through the hole, hold the tag between thumb and index finger.
//  QR: HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/P (trick page Pendel), inlay
//  QR_DEPTH deep in the underside (bed side, best surface), mirrored so it
//  reads correctly on the finished tag. Second colour = QR part.
//  Fits flat on the floor of the PENDEL pocket in the magic case
//  (27.6 x 47 x 15.5), pendulum on top: 2.4 + 13 < 15.5.
//    openscad -D 'part="anhaenger"' -o pendel_anhaenger.stl    pendel_anhaenger.scad
//    openscad -D 'part="qr"'        -o pendel_anhaenger_qr.stl pendel_anhaenger.scad
// =====================================================================

part = "alle"; // [alle, anhaenger, qr]

TAG_W   = 24.0;    // width
TAG_L   = 30.0;    // length incl. lug with the thread hole
TAG_T   = 2.4;     // thickness (12 layers of 0.2)
TAG_R   = 3.0;     // corner radius
HOLE_D  = 2.0;     // thread hole
HOLE_Y  = 3.0;     // hole centre from the top edge
CHAMFER = 0.4;     // top edges

QR_MOD   = 0.76;   // module size (25 modules -> 19.0 mm)
QR_DEPTH = 0.6;    // inlay depth (3 layers of 0.2)

// HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/P, version 2-M (segno), alphanumeric
// (upper case, HTTP so 38 characters fit). Row 0 = top, "1" = dark module.
QR = [
    "1111111010000101001111111",
    "1000001001110000101000001",
    "1011101011010101001011101",
    "1011101000010011001011101",
    "1011101000110101101011101",
    "1000001010011101101000001",
    "1111111010101010101111111",
    "0000000000100000000000000",
    "1010001101010011000100101",
    "1011010011101101010011001",
    "1101101100000001100110101",
    "0010010010100101110001101",
    "1100001100001111111010010",
    "0101000001100100010100101",
    "1111101001011011001000110",
    "0010110010010001101111110",
    "1111111110101110111110011",
    "0000000011111010100011111",
    "1111111011000010101010111",
    "1000001001011111100011011",
    "1011101000001101111110011",
    "1011101001010010101100110",
    "1011101011001101001100011",
    "1000001000001001011011001",
    "1111111011010011101011111"
];

$fn = 48;
QR_S  = len(QR)*QR_MOD;
QR_CY = -TAG_L/2 + TAG_W/2;            // QR centred in the square lower part
assert(QR_S < TAG_W - 4, "QR code too wide for the tag");
assert(HOLE_Y + HOLE_D/2 + 1 < TAG_L - TAG_W + (TAG_W - QR_S)/2, "hole too close to the QR code");

module outline(d = 0) offset(r = TAG_R - d) square([TAG_W - 2*TAG_R, TAG_L - 2*TAG_R], center = true);

module qr_2d() {
    n = len(QR);
    translate([0, QR_CY]) mirror([1, 0, 0])
        for (r = [0:n-1]) for (c = [0:n-1])
            if (QR[r][c] == "1")
                translate([(c - n/2)*QR_MOD, (n/2 - 1 - r)*QR_MOD]) square(QR_MOD + 0.002);
}

module anhaenger() {
    difference() {
        hull() {
            linear_extrude(TAG_T - CHAMFER) outline();
            linear_extrude(TAG_T) outline(CHAMFER);
        }
        translate([0, TAG_L/2 - HOLE_Y, -1]) cylinder(h = TAG_T + 2, d = HOLE_D);
        translate([0, 0, -1]) linear_extrude(QR_DEPTH + 1) qr_2d();
    }
}

module qr() linear_extrude(QR_DEPTH) qr_2d();

if (part == "anhaenger") anhaenger();
else if (part == "qr") qr();
else { color("Gold") anhaenger(); color("Black") qr(); }
