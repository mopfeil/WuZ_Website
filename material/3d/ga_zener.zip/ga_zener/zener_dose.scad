// =====================================================================
//  Transport box for the eight symbol discs -- screw lid
//  v2 (15.10.2026): groove lid instead of the press-fit pocket
//  v2.1 (06.11.2026): groove support as its own part (support filament)
// ---------------------------------------------------------------------
//  Round box with a screw lid for the discs from zener_scheiben.scad
//  (diameter 20, thickness 2.4). The well takes seven discs; the eighth
//  (top) disc sits in a chamber inside the lid plate.
//
//  Hidden disc in the lid: above a narrow lip (LIP_H, opening just wider
//  than a disc) the lid has a chamber one disc high whose groove runs all
//  round, GROOVE_SLIDE wider than the opening. Tilt the closed box: the
//  top disc slides to the low side into the groove and hooks under the
//  lip. Lift the lid off while that side stays low and the disc comes away
//  with the lid; it tilts a little until its hooked edge jams against the
//  groove ceiling and hangs hidden inside the lid. Tip the lid the other
//  way (hooked side up, steeply, a light tap helps) and the disc slides out
//  of the groove and drops. The groove is round, so no orientation mark is
//  needed: the side that is low when the lid comes off is the hold side.
//  Hold too weak: reduce GROOVE_GAP; disc does not slide in: increase it.
//  Trick: https://wissenschaftundzauberkunst.de/Z/ (QR code on the floor).
//
//  QR code (wissenschaftundzauberkunst.de/Z) as an inlay in the underside
//  of the body, second filament colour. Load zener_dose_unterteil.stl and
//  zener_dose_qr.stl together as ONE object with two parts (same origin),
//  QR part -> dark filament. Easiest: open zener_dose.3mf.
//  For Bambu "right-click body -> Add part -> Load" use zener_dose_qr_teil.stl
//  instead: Bambu places an added part relative to the CENTRE of the body
//  (10.5 above the bed), so that file is shifted down by half the body height.
//
//  Print: body upright (floor on the bed), lid with its top on the bed.
//  The lip hangs GROOVE_SLIDE = 2 mm over the groove; the slicer's own
//  supports there came out badly. v2.1: zener_dose_deckel_stuetze.stl fills
//  the groove as SUP_N ring segments -> assign the support filament
//  (Support for PLA). Slicer supports off. After printing push each segment
//  towards the centre under the lip and lift it out.
//  Same origin as zener_dose_deckel.stl; for Bambu "Add part -> Load" use
//  zener_dose_deckel_stuetze_teil.stl (relative to the lid centre).
//  Thread code from InverterMagnet_V8_Wendedose_6mm.scad.
//    openscad -D 'part="unterteil"' -o zener_dose_unterteil.stl zener_dose.scad
//    openscad -D 'part="qr"'        -o zener_dose_qr.stl        zener_dose.scad
//    openscad -D 'part="qr_teil"'   -o zener_dose_qr_teil.stl   zener_dose.scad
//    openscad -D 'part="deckel"'    -o zener_dose_deckel.stl    zener_dose.scad
//    openscad -D 'part="deckel_stuetze"'      -o zener_dose_deckel_stuetze.stl      zener_dose.scad
//    openscad -D 'part="deckel_stuetze_teil"' -o zener_dose_deckel_stuetze_teil.stl zener_dose.scad
// =====================================================================

/* [Selection] */
part = "druckplatte"; // [baugruppe, schnitt, unterteil, qr, qr_teil, deckel, deckel_stuetze, deckel_stuetze_teil, druckplatte]

/* [Discs] */
DISC_D = 20.0;         // disc diameter
DISC_T = 2.4;          // disc thickness
N_DISCS = 8;           // the box takes this many (N_DISCS-1 in the well, 1 in the lid)

/* [Box] */
WELL_CLR = 0.4;        // radial play of the discs in the well
FLOOR = 1.2;           // floor thickness (6 layers)
WALL = 1.2;            // wall well -- thread root
LID_TOP = 1.2;         // lid plate above the chamber
SKIRT_WALL = 2.0;      // lid wall outside the inner thread
SEAM = 0.3;            // gap between lid skirt and body shoulder
CHAMFER = 0.8;         // outer chamfers

/* [Groove chamber in the lid] */
LIP_H        = 0.8;    // lip under the chamber (4 layers)
LIP_CLR      = 0.3;    // radial play of a disc in the lip opening
GROOVE_SLIDE = 2.0;    // groove depth beyond the lip edge = hook overlap
GROOVE_GAP   = 0.4;    // chamber height above one disc (2 layers)

/* [Groove support (support filament)] */
SUP_N     = 6;         // ring segments (removable one by one through the lip opening)
SUP_SLOT  = 0.8;       // gap between segments (lip bridges it)
SUP_IN    = 1.0;       // segments reach this far inside the lip edge (grip, clean edge)

/* [QR code in the floor] */
QR_ON    = true;       // QR inlay in the underside of the body
QR_MOD   = 0.76;       // module size (25 modules -> 19.0 mm, corners 0.7 inside the chamfer)
QR_DEPTH = 0.6;        // inlay depth (3 layers of 0.2)
// HTTP://WISSENSCHAFTUNDZAUBERKUNST.DE/Z, version 2, error correction M (segno),
// links to the trick explanation (unlisted page /Z/, 15.10.2026).
// Upper case so it fits alphanumeric mode (25 instead of 29 modules);
// scheme and host are case-insensitive, the folder on the server is "Z".
// HTTP instead of HTTPS: 38 characters still fit version 2-M, the server
// redirects to https. Row 0 = top, "1" = dark module.
QR = [
    "1111111011100101001111111",
    "1000001001001000101000001",
    "1011101011001101001011101",
    "1011101001000011001011101",
    "1011101001000101101011101",
    "1000001011010101101000001",
    "1111111010101010101111111",
    "0000000000110000000000000",
    "1010001100000011000100101",
    "0010010100101101010011001",
    "1110011000001001100110101",
    "0100000010100101110001101",
    "1101011011111111111010010",
    "0110010110000100010100101",
    "1100111011101011001000110",
    "0010010100001001101111110",
    "1101001100001110111110011",
    "0000000011111010100011111",
    "1111111010100010101010111",
    "1000001001011111100011011",
    "1011101001101101111110011",
    "1011101001110010101100110",
    "1011101011001101001100011",
    "1000001000001001011011001",
    "1111111010110011101011111"
];

/* [Thread] */
THREAD_L = 5.0;        // thread length
P     = 2.0;           // pitch
H_TH  = 1.0;           // thread depth (radial)
CLR   = 0.35;          // radial play of the inner thread (stiff: 0.4-0.5)

/* [Knurl] */
KNURL_N = 30;
KNURL_R = 1.0;

/* [Resolution] */
TH_SEG = 128;
TH_DZ  = 0.125;
$fn = 96;

// ---------- derived values ----------
WELL_R  = DISC_D/2 + WELL_CLR;                 // 10.4
// the top of disc N_DISCS-1 is level with the lip top, so the last disc
// lies completely in the chamber and can slide into the groove
WELL_H  = (N_DISCS - 1)*DISC_T - LIP_H;        // 16.0
R_MIN   = WELL_R + WALL;                       // thread root, 11.6
D_MAJ   = 2*(R_MIN + H_TH);                    // outer thread, 25.2
GRIP_D  = 2*(R_MIN + H_TH + CLR + SKIRT_WALL); // outer diameter, 29.9
Z_SH    = -THREAD_L - SEAM;                    // body shoulder
Z_BOT   = -WELL_H - FLOOR;                     // body bottom
LIP_R   = DISC_D/2 + LIP_CLR;                  // lip opening, 10.3
CHAMBER_R = LIP_R + GROOVE_SLIDE;              // groove, 12.3
CHAMBER_H = DISC_T + GROOVE_GAP;               // 2.8
PLATE   = LIP_H + CHAMBER_H + LID_TOP;         // lid plate, 4.8
echo(GRIP_D = GRIP_D, body_h = -Z_BOT, total_h = PLATE - Z_BOT,
     hold_tilt_deg = atan(GROOVE_GAP/GROOVE_SLIDE));
EPS = 0.01;

assert(LIP_R <= WELL_R, "lip opening wider than the well");
assert(CHAMBER_R < GRIP_D/2 - KNURL_R/2 - 1.5, "groove too close to the knurl");
assert(!QR_ON || len(QR)*QR_MOD*sqrt(2)/2 < GRIP_D/2 - CHAMFER - 0.5, "QR code reaches the chamfer");
assert(!QR_ON || QR_DEPTH < FLOOR - 0.4, "QR inlay too deep for the floor");

// ===================================================================
//  Thread polyhedron: r(a,z) = r_min + H*profile(u),  u = z/P - a/360
//  Trapezoid ~60 deg, right-handed.
//  cone_top : 45 deg lead chamfer at the top end (outer thread), -1 = off
//  lead_in  : [z_ref, r_ref] 45 deg widening downwards (inner thread), [] = off
// ===================================================================
function clamp01(x) = min(1, max(0, x));
function tprofile(u) = clamp01((abs(u - 0.5)*2 - 0.2) / 0.6);
function frac(x) = x - floor(x);

function th_r(a, z, rmin, H, z0, z1, cone_top, lead_in, p = P) =
    let(u  = frac((z - z0)/p - a/360),
        r0 = rmin + H*tprofile(u),
        r1 = cone_top > 0 ? max(min(r0, cone_top + (z1 - z)), rmin) : r0,
        r2 = len(lead_in) == 2 ? max(r1, lead_in[1] - (z - lead_in[0])) : r1)
    r2;

module thread_body(rmin, H, z0, z1, cone_top = -1, lead_in = [], p = P) {
    nz = round((z1 - z0)/TH_DZ) + 1;
    na = TH_SEG;
    pts = concat(
        [for (j = [0:nz-1]) for (i = [0:na-1])
            let(z = z0 + (z1 - z0)*j/(nz-1), a = 360*i/na,
                r = th_r(a, z, rmin, H, z0, z1, cone_top, lead_in, p))
            [r*cos(a), r*sin(a), z]],
        [[0, 0, z0], [0, 0, z1]]);
    cb = nz*na; ct = cb + 1;
    function id(j, i) = j*na + (i % na);
    faces = concat(
        [for (j = [0:nz-2]) for (i = [0:na-1]) each [
            [id(j,i), id(j+1,i+1), id(j,i+1)],
            [id(j,i), id(j+1,i),   id(j+1,i+1)]]],
        [for (i = [0:na-1]) [cb, id(0,i), id(0,i+1)]],
        [for (i = [0:na-1]) [ct, id(nz-1,i+1), id(nz-1,i)]]);
    polyhedron(points = pts, faces = faces, convexity = 10);
}

module knurl(z0, h, d = GRIP_D, n = KNURL_N, r = KNURL_R) {
    for (k = [0:n-1])
        rotate([0, 0, 360*k/n])
            translate([d/2 + r/2, 0, z0 - 1])
                cylinder(h = h + 2, r = r, $fn = 24);
}

// ---------- body (top rim = z 0) ----------
module unterteil() {
    h = Z_SH - Z_BOT;
    difference() {
        union() {
            intersection() {
                difference() {
                    translate([0, 0, Z_BOT]) cylinder(h = h, d = GRIP_D);
                    knurl(Z_BOT, h);
                }
                translate([0, 0, Z_BOT]) cylinder(h = h, r1 = GRIP_D/2 - CHAMFER, r2 = GRIP_D/2 - CHAMFER + h);
            }
            thread_body(R_MIN, H_TH, Z_SH - EPS, 0, cone_top = D_MAJ/2 - 0.6);
        }
        translate([0, 0, -WELL_H]) cylinder(h = WELL_H + 1, r = WELL_R);
        // small chamfer at the well opening
        translate([0, 0, -0.4]) cylinder(h = 0.4 + EPS, r1 = WELL_R, r2 = WELL_R + 0.4);
        if (QR_ON) translate([0, 0, Z_BOT - 1]) linear_extrude(QR_DEPTH + 1) qr_2d();
    }
}

// ---------- QR code ----------
// Mirrored (x -> -x) so it reads correctly when the box is turned over.
module qr_2d() {
    n = len(QR);
    mirror([1, 0, 0])
        for (r = [0:n-1]) for (c = [0:n-1])
            if (QR[r][c] == "1")
                translate([(c - n/2)*QR_MOD, (n/2 - 1 - r)*QR_MOD]) square(QR_MOD + 0.002);
}

module qr_inlay() translate([0, 0, Z_BOT]) linear_extrude(QR_DEPTH) qr_2d();

// ---------- lip opening + groove chamber (lip from z 0, chamber above) ----------
module chamber() {
    translate([0, 0, -1]) cylinder(h = LIP_H + 1 + EPS, r = LIP_R);
    translate([0, 0, LIP_H]) cylinder(h = CHAMBER_H, r = CHAMBER_R);
}

// ---------- groove support (lid coordinates, fills the chamber ring) ----------
module groove_support() {
    translate([0, 0, LIP_H]) difference() {
        cylinder(h = CHAMBER_H, r = CHAMBER_R);
        translate([0, 0, -1]) cylinder(h = CHAMBER_H + 2, r = LIP_R - SUP_IN);
        for (k = [0:SUP_N-1]) rotate([0, 0, 360*k/SUP_N])
            translate([0, -SUP_SLOT/2, -1]) cube([CHAMBER_R + 1, SUP_SLOT, CHAMBER_H + 2]);
    }
}

// ---------- lid (plate underside = z 0) ----------
module deckel() {
    z0 = Z_SH + SEAM; h = PLATE - z0;
    difference() {
        intersection() {
            difference() {
                translate([0, 0, z0]) cylinder(h = h, d = GRIP_D);
                knurl(z0, h);
            }
            translate([0, 0, z0]) cylinder(h = h, r1 = GRIP_D/2 - CHAMFER + h, r2 = GRIP_D/2 - CHAMFER);
        }
        thread_body(R_MIN + CLR, H_TH, Z_SH - P, EPS,
                    lead_in = [z0, D_MAJ/2 + CLR + 0.6]);
        chamber();
    }
}

// ---------- view ----------
module half(cut) {
    if (cut) difference() { children(); translate([-100, -200, -100]) cube(200); }
    else children();
}

module baugruppe(cut = false) {
    color("Tan") half(cut) unterteil();
    if (QR_ON) color("Black") half(cut) qr_inlay();
    color("DarkSeaGreen", cut ? 1 : 0.85) half(cut) deckel();
    for (k = [0:N_DISCS-2])   // seven discs in the well, the eighth in the lid
        color(k % 2 ? "White" : "LightSteelBlue") half(cut)
            translate([0, 0, -WELL_H + k*DISC_T]) cylinder(h = DISC_T, d = DISC_D);
    // top disc pushed into the groove (hook side -x, the side of the cut view)
    color("RoyalBlue") half(cut)
        translate([-(CHAMBER_R - DISC_D/2), 0, LIP_H]) cylinder(h = DISC_T, d = DISC_D);
}

// ---------- output ----------
module lid_print() rotate([180, 0, 0]) translate([0, 0, -PLATE]) deckel();   // top on the bed
module sup_print() rotate([180, 0, 0]) translate([0, 0, -PLATE]) groove_support();
LID_H = PLATE - (Z_SH + SEAM);                 // printed lid height

if (part == "unterteil") translate([0, 0, -Z_BOT]) unterteil();
else if (part == "qr") translate([0, 0, -Z_BOT]) qr_inlay();
else if (part == "qr_teil") translate([0, 0, -Z_BOT/2]) qr_inlay();   // relative to the body centre
else if (part == "deckel") lid_print();
else if (part == "deckel_stuetze") sup_print();
else if (part == "deckel_stuetze_teil") translate([0, 0, -LID_H/2]) sup_print();   // relative to the lid centre
else if (part == "baugruppe") baugruppe();
else if (part == "schnitt") baugruppe(cut = true);
else if (part == "druckplatte") {
    translate([0, 0, -Z_BOT]) unterteil();
    if (QR_ON) translate([0, 0, -Z_BOT]) qr_inlay();
    translate([GRIP_D + 5, 0, 0]) { lid_print(); sup_print(); }
}
