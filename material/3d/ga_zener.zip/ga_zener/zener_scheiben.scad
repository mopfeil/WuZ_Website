// =====================================================================
//  Symbol discs, two-colour inlay -- v4 flat (14.10.2026)
// ---------------------------------------------------------------------
//  Seven discs with one symbol each (the five Zener symbols plus triangle
//  and heart) and an eighth disc that carries symbol 1 on BOTH faces.
//
//  v4: flat discs, no rim. The symbol is embedded INLAY mm deep and flush
//  with the face; the body has the matching cavity. Sized for a 0.4 mm
//  nozzle and 0.2 mm layers: strokes 1.6 (4 lines), symbol gaps
//  >= 0.8 (2 lines), all heights multiples of 0.2. Any symbol detail
//  thinner than MIN_FEATURE (or gap narrower) is removed by clean2d().
//  Disc 8 has no touch mark any more (notch removed 14.10.2026, v4.1);
//  transport box: zener_dose.scad.
//  Older versions: v2_flach/ (rim 0.5), v3_rand/ (rim 1.0).
//
//  Disc: diameter 20, thickness T. Symbol face on top (z = T); disc 8 also
//  on the bottom (mirrored, reads correctly after turning the disc over).
//
//  Two-colour print (Bambu): open zener_scheiben.3mf -- one object per disc,
//  parts body = filament 1, symbol = filament 2. Or export the parts with
//  the SAME coordinates and load them "as one object with multiple parts":
//    openscad -D disc=3 -D 'part="symbol"' -o scheibe3_symbol.stl zener_scheiben.scad
//  disc = 0 lays out all eight discs on one plate.
// =====================================================================

/* [Selection] */
disc = 0;              // 1..8, 0 = all eight on one plate
part = "body";         // [body, symbol, both]

/* [Disc] */
D       = 20;          // diameter
T       = 2.4;         // total thickness (12 layers of 0.2)
INLAY   = 0.6;         // symbol depth from the face (3 layers of 0.2)
SYM_SIZE = 14;         // symbols are drawn to fit roughly this square
LINE    = 1.6;         // stroke width (4 lines at 0.4)
MIN_FEATURE = 0.8;     // smallest stroke / gap kept (2 lines at 0.4)
DOUBLE_SYMBOL = 1;     // symbol on both faces of disc 8

/* [Plate] */
GAP = 4;               // spacing between discs on the plate

$fn = 96;
R = D / 2;

// ---------------------------------------------------------------- symbols
module ring2d(d, w) { difference() { circle(d = d + w); circle(d = d - w); } }

module outline(w) {    // stroke of width w centred on the shape's edge
    difference() {
        offset(r =  w / 2) children();
        offset(r = -w / 2) children();
    }
}

module stroke_path(pts, w) {   // round-capped polyline
    for (i = [0 : len(pts) - 2])
        hull() { translate(pts[i]) circle(d = w, $fn = 24);
                 translate(pts[i + 1]) circle(d = w, $fn = 24); }
}

module sym_circle()   ring2d(SYM_SIZE - LINE, LINE);
module sym_cross()    { square([SYM_SIZE, LINE * 1.2], center = true);
                        square([LINE * 1.2, SYM_SIZE], center = true); }
module sym_waves() {
    amp = 1.2; len = SYM_SIZE - LINE; n = 40;
    for (y = [-4, 0, 4])
        stroke_path([for (i = [0 : n]) [-len / 2 + len * i / n,
                                         y + amp * sin(360 * 1.5 * i / n)]], LINE);
}
module sym_square()   outline(LINE) square(SYM_SIZE * 0.78 - LINE, center = true);
module sym_star() {
    ro = SYM_SIZE / 2 - LINE / 2; ri = ro * 0.42;
    outline(LINE) polygon([for (i = [0 : 9])
        let(r = i % 2 ? ri : ro, a = 90 + i * 36) [r * cos(a), r * sin(a) - 0.6]]);
}
module sym_triangle() {
    r = SYM_SIZE / 2 - LINE / 2 + 0.6;
    outline(LINE) polygon([for (a = [90, 210, 330]) [r * cos(a), r * sin(a) - 1.4]]);
}
module sym_heart() {
    s = (SYM_SIZE - LINE) / 34;            // classic parametric heart, width ~34
    outline(LINE) scale(s) translate([0, 1.5]) polygon([for (t = [0 : 4 : 356])
        [16 * pow(sin(t), 3),
         13 * cos(t) - 5 * cos(2 * t) - 2 * cos(3 * t) - cos(4 * t)]]);
}

module symbol2d(n) {
    if      (n == 1) sym_circle();
    else if (n == 2) sym_cross();
    else if (n == 3) sym_waves();
    else if (n == 4) sym_square();
    else if (n == 5) sym_star();
    else if (n == 6) sym_triangle();
    else if (n == 7) sym_heart();
}

// ---------------------------------------------------------------- disc
// removes strokes and gaps narrower than MIN_FEATURE (closing, then opening)
module clean2d() {
    e = MIN_FEATURE / 2;
    offset(r = e) offset(r = -e)       // opening: drop thin strokes
        offset(r = -e) offset(r = e)   // closing: fill narrow gaps
            children();
}

// z = 0 is the back face, z = T the symbol face.
module body(n) {
    difference() {
        cylinder(r = R, h = T);
        symbols(n);   // cavity for the inlay
    }
}

module symbols(n) {
    s = n == 8 ? DOUBLE_SYMBOL : n;
    translate([0, 0, T - INLAY]) linear_extrude(INLAY) clean2d() symbol2d(s);
    if (n == 8)    // back face, mirrored
        linear_extrude(INLAY) clean2d() mirror([1, 0]) symbol2d(s);
}

module disc_part(n) {
    if (part == "body" || part == "both") color("white") body(n);
    if (part == "symbol" || part == "both") color("royalblue") symbols(n);
}

// ---------------------------------------------------------------- output
if (disc == 0) {
    for (n = [1 : 8])
        translate([((n - 1) % 4) * (D + GAP), -floor((n - 1) / 4) * (D + GAP), 0])
            disc_part(n);
} else disc_part(disc);
